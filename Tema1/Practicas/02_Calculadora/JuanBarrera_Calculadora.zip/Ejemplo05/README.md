# Ejemplo05 REALIZADO POR JUAN BARRERA CUESTA 2ºDAM

Ejercicio que consiste en realizar una calcula en Android usando Java

---------------------

# Diseño principal

<img src = "https://i.imgur.com/2GbDAdA.jpg" width="250" height="450">

---------------------

# Funcionamiento

A la hora de analizar cómo se ha realizado el funcionamiento de esta aplicación, se pueden tener en cuenta varios aspectos.

- Cada vez que se pulse un número u operador (incluyendo el punto decimal) se recogerá el texto de dicho botón y se agregará al visor junto con la información que ya mostraba.
- Los botones 'DEL' y 'C' actúan de forma que elimina el último caracter del visor o reestableciendo el visor de forma que no muestra información alguna (información a 0), respectivamente.
- El botón igual recoge toda la cadena del visor y, aplicando ciertas instrucciones, convierte la cadena en una operación completa, de modo que podemos recoger el dato resultando y pasarlo al visor en forma de texto.
- Si se intenta introducir una operación incompleta (8x2+), la calculadora no tendrá en cuenta el último carácter.
- Del mismo modo, si el visor está en blanco (información a 0), no se permitir

---------------------

# Demostración de la aplicación

https://user-images.githubusercontent.com/101633372/195692860-9e162a69-470d-4abe-a1d8-6fbeefb42e6c.mp4

---------------------

# [Descarga la apk](https://github.com/Acaluw/Ejemplo05/blob/master/Calculadora2DAM.apk)
