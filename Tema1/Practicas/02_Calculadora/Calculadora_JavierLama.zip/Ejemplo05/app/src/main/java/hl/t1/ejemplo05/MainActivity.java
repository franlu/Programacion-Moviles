package hl.t1.ejemplo05;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.udojava.evalex.Expression;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {

    Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7
            ,btn8,btn9,btnSuma,btnResta,btnMult,btnDiv,btnComa,btnC,btnDel,btnIgual;

    EditText pantalla;
    String cadena=" ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        pantalla = findViewById(R.id.etVisor);

        btn0 = findViewById(R.id.btn0);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);
        btnSuma = findViewById(R.id.btnSuma);
        btnResta = findViewById(R.id.btnResta);
        btnDiv = findViewById(R.id.btnDiv);
        btnMult = findViewById(R.id.btnMult);
        btnComa = findViewById(R.id.btnComa);
        btnC = findViewById(R.id.btnC);
        btnDel = findViewById(R.id.btnDel);
        btnIgual = findViewById(R.id.btnIgual);

        btn0.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);

        btnSuma.setOnClickListener(this);
        btnResta.setOnClickListener(this);
        btnMult.setOnClickListener(this);
        btnDiv.setOnClickListener(this);
        btnComa.setOnClickListener(this);
        btnC.setOnClickListener(this);
        btnIgual.setOnClickListener(this);
        btnDel.setOnClickListener(this);
    }
    @Override
    public void onClick(View view){
        Button b =(Button) view;
        modificarCadena(b.getText().toString());
    }
    public void modificarCadena(String s){
        switch(s){
            case "DEL":
                if(cadena.equals("")){
                }else{
                    cadena = cadena.substring(0,cadena.length()-1);
                    pantalla.setText(cadena);
                }
                break;
            case "C":
                cadena="";
                pantalla.setText(cadena);
                break;
            case "=":
                if(cadena.equals("") || (cadena.contains("/") && cadena.contains("0")) ){}
                else{
                    String comp = cadena.substring(cadena.length()-1);
                    if(comp.equals("+") || comp.equals("-") || comp.equals("*") || comp.equals("/")
                            || comp.equals(".")){

                        cadena = cadena.substring(0,cadena.length()-1);
                        Expression calculo = new Expression(cadena);
                        String resultado = calculo.eval().toString();
                        cadena = "";
                        pantalla.setText(resultado);
                    }else{
                        Expression calculo = new Expression(cadena);
                        String resultado = calculo.eval().toString();
                        cadena = "";
                        pantalla.setText(resultado);
                    }
                }
                break;
            default:
                if(s.equals("+") || s.equals("-") || s.equals("*") || s.equals("/") || s.equals(".")){
                    if(cadena.equals("")){
                    }else{
                        cadena+=s;
                        pantalla.setText(cadena);
                    }
                }else{
                    cadena+=s;
                    pantalla.setText(cadena);
                }
                break;
        }
    }
}