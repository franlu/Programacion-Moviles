package hl.t1.ejemplo05;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

import java.util.List;

import hl.t1.ejemplo05.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    List<Button> buttons;
    ActivityMainBinding b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b = ActivityMainBinding.inflate(getLayoutInflater());
        View view = b.getRoot();
        setContentView(view);

        buttons = List.of(
                b.b1, b.b2, b.b3, b.b4, b.b5, b.b6, b.b7, b.b8, b.b9, b.b0,
                b.bSumar, b.bRestar, b.bMultiiplicar, b.bDIvidir, b.bIgual,
                b.bAllClear, b.bClear, b.bAbreP, b.bCierraP, b.bDecimal);
        asignarListener();
        b.et1.setRawInputType(InputType.TYPE_NULL);
    }

    private void asignarListener() {
        for (Button i : buttons)
            i.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String bPulsado = ((Button) view).getText().toString();
        String sET1 = b.et1.getText().toString();

        if (view.getId() == R.id.bClear) {
            if (sET1.length() >= 1)
                sET1 = sET1.substring(0, sET1.length() - 1);
        } else
            sET1 += bPulsado;


        if (view.getId() == R.id.bAllClear) {
            b.et1.setText("");
            b.et2.setText("0");
            return;
        }

        if (view.getId() == R.id.bIgual) {
            b.et1.setText(b.et2.getText());
            return;
        }

        if (view.getId() == R.id.bClear && sET1.length() == 0)
            b.et2.setText("0");


        String resultado = getResultado(sET1);

        if (!resultado.equals("Error")) {
            if (!resultado.startsWith("org"))
                b.et2.setText(resultado);
        }

        b.et1.setText(sET1);
    }

    private String getResultado(String operacion) {
        try {
            Context context = Context.enter();
            context.setOptimizationLevel(-1);
            Scriptable scriptable = context.initStandardObjects();
            String finalResult = context.evaluateString(scriptable, operacion, "Javascript", 1, null).toString();
            if (finalResult.endsWith(".0")) {
                finalResult = finalResult.replace(".0", "");
            }
            return finalResult;
        } catch (Exception e) {
            return "Error";
        }
    }

}