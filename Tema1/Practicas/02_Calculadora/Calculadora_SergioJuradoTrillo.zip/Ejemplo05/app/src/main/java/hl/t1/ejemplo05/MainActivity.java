package hl.t1.ejemplo05;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView Pantalla;
    double n1;
    double n2;
    double resultado;
    String operador;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void eliminar(View view){
        n1=0;
        n2=0;
        resultado=0;
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText("");
    }
    public void boton0(View view){
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText(Pantalla.getText()+"0");
    }
    public void boton1(View view){
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText(Pantalla.getText()+"1");
    }

    public void boton2(View view){
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText(Pantalla.getText()+"2");
    }

    public void boton3(View view){
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText(Pantalla.getText()+"3");
    }

    public void boton4(View view){
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText(Pantalla.getText()+"4");
    }

    public void boton5(View view){
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText(Pantalla.getText()+"5");
    }

    public void boton6(View view){
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText(Pantalla.getText()+"6");
    }

    public void boton7(View view){
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText(Pantalla.getText()+"7");
    }

    public void boton8(View view){
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText(Pantalla.getText()+"8");
    }

    public void boton9(View view){
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText(Pantalla.getText()+"9");
    }

    public void botonComa(View view){
        Pantalla =  (TextView) findViewById(R.id.etVisor);
        Pantalla.setText(Pantalla.getText()+",");
    }

    public  void pulsarNumeroUnoClick(View view){
        Pantalla = (TextView) findViewById(R.id.etVisor);
        n1 = Double.parseDouble(Pantalla.getText().toString());
        Pantalla.setText(" ");
    }

    public void sumar(View view){
        operador = "+";
        pulsarNumeroUnoClick(view);
    }

    public void restar(View view){
        operador = "-";
        pulsarNumeroUnoClick(view);
    }

    public void multiplicar(View view){
        operador = "*";
        pulsarNumeroUnoClick(view);
    }

    public void dividir(View view){
        operador = "/";
        pulsarNumeroUnoClick(view);
    }

    public void igual(View view){
        Pantalla = (TextView)findViewById(R.id.etVisor);
        n2 = Double.parseDouble(Pantalla.getText().toString());
        if(operador.equals("+")){
            resultado =  n1 + n2;
        }
        else  if(operador.equals("-")){
            resultado =  n1 - n2;
        }
        else  if(operador.equals("*")){
            resultado =  n1 * n2;
        }
        else  if(operador.equals("/")){
            resultado =  n1 / n2;
        }
        Pantalla.setText(" " + resultado);
    }

}