package hl.t1.ejemplo05;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.udojava.evalex.Expression;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnN0,btnN1,btnN2,btnN3,btnN4,btnN5,btnN6,btnN7
    ,btnN8,btnN9,btnSum,btnRes,btnMult,btnDiv,btnDec,btnC,btnDel,btnIgual;

    EditText visualizador;

    String cadena="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        visualizador = findViewById(R.id.etVisor);

        btnN0 = findViewById(R.id.btnN0);
        btnN1 = findViewById(R.id.btnN1);
        btnN2 = findViewById(R.id.btnN2);
        btnN3 = findViewById(R.id.btnN3);
        btnN4 = findViewById(R.id.btnN4);
        btnN5 = findViewById(R.id.btnN5);
        btnN6 = findViewById(R.id.btnN6);
        btnN7 = findViewById(R.id.btnN7);
        btnN8 = findViewById(R.id.btnN8);
        btnN9 = findViewById(R.id.btnN9);
        btnSum = findViewById(R.id.btnSum);
        btnRes = findViewById(R.id.btnRest);
        btnDiv = findViewById(R.id.btnDiv);
        btnMult = findViewById(R.id.btnMult);
        btnDec = findViewById(R.id.btnDec);
        btnC = findViewById(R.id.btnC);
        btnDel = findViewById(R.id.btnRetro);
        btnIgual = findViewById(R.id.btnIgual);

        btnN0.setOnClickListener(this);
        btnN1.setOnClickListener(this);
        btnN2.setOnClickListener(this);
        btnN3.setOnClickListener(this);
        btnN4.setOnClickListener(this);
        btnN5.setOnClickListener(this);
        btnN6.setOnClickListener(this);
        btnN7.setOnClickListener(this);
        btnN8.setOnClickListener(this);
        btnN9.setOnClickListener(this);

        btnC.setOnClickListener(this);
        btnDel.setOnClickListener(this);

        btnDiv.setOnClickListener(this);
        btnMult.setOnClickListener(this);
        btnRes.setOnClickListener(this);
        btnSum.setOnClickListener(this);
        btnDec.setOnClickListener(this);

        btnIgual.setOnClickListener(this);
    }

    @Override
    public void onClick(View view){
        Button b =(Button) view;
        modificarCadena(b.getText().toString());
    }

    public void modificarCadena(String s){
        switch(s){
            case "DEL":
                if(cadena.equals("")){
                }else{
                    cadena = cadena.substring(0,cadena.length()-1);
                    visualizador.setText(cadena);
                }
                break;
            case "C":
                cadena="";
                visualizador.setText(cadena);
                break;
            case "=":
                String comp = cadena.substring(cadena.length()-1);
                if(comp.equals("+") || comp.equals("-") || comp.equals("*") || comp.equals("/")
                        || comp.equals(".")){
                    cadena = cadena.substring(0,cadena.length()-1);
                    Expression calculo = new Expression(cadena);
                    String resultado = calculo.eval().toString();
                    cadena = "";
                    visualizador.setText(resultado);
                }else{
                    Expression calculo = new Expression(cadena);
                    String resultado = calculo.eval().toString();
                    cadena = "";
                    visualizador.setText(resultado);
                }
                break;
            default:
                if(s.equals("+") || s.equals("-") || s.equals("*") || s.equals("/") || s.equals(".")){
                    if(cadena.equals("")){
                    }else{
                        cadena+=s;
                        visualizador.setText(cadena);
                    }
                }else{
                    cadena+=s;
                    visualizador.setText(cadena);
                }
                break;
        }
    }
}