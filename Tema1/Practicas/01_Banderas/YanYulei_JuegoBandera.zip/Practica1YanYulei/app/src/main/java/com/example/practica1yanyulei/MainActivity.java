package com.example.practica1yanyulei;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
/**
 * @author Yulei Yan
 * Módulo: Programación de Dispositivos Móviles
 * Curso: 2ºDAM
 */
public class MainActivity extends AppCompatActivity {

    ImageButton ib1, ib2;
    Button bJugarDeNuevo;
    TextView tvSelecciona, tvTuPuntuacion;

    int nAcierto = -1;
    int puntuacion;
    int nAleatorioBandera1;
    int nAleatorioBandera2;
    int nAleatorioSeleccionaBandera;
    int banderaSeleccionada;
    String[] paises = new String[]{
            "China", "España", "Colombia", "Costa Rica"
    };
    int[] banderas = new int[]{
            R.drawable.cn, R.drawable.es, R.drawable.co, R.drawable.cr
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ib1 = (ImageButton) findViewById(R.id.ib1);
        ib2 = (ImageButton) findViewById(R.id.ib2);
        bJugarDeNuevo = (Button) findViewById(R.id.bJugarDeNuevo);
        tvSelecciona = findViewById(R.id.tvSelecciona);
        tvTuPuntuacion = findViewById(R.id.tvTuPuntuacion);

        generarNAleatorio();
        cambiarBanderaYTexto();

    }

    public void pulsar(View view) {
        nAcierto++;
        switch (view.getId()) {
            case R.id.ib1:
                if (nAleatorioBandera1 == banderaSeleccionada)
                    puntuacion++;
                else
                    puntuacion--;
                break;
            case R.id.ib2:
                if (nAleatorioBandera2 == banderaSeleccionada)
                    puntuacion++;
                else
                    puntuacion--;
                break;
        }
        generarNAleatorio();
        cambiarBanderaYTexto();
        perder();

    }

    private void perder() {
        if (puntuacion < 0) {
            tvTuPuntuacion.setText("Has perdido todos los puntos." + "\n \n Número de aciertos: " + nAcierto);
            ib1.setVisibility(View.INVISIBLE);
            ib2.setVisibility(View.INVISIBLE);
            tvSelecciona.setVisibility(View.INVISIBLE);
            bJugarDeNuevo.setVisibility(View.VISIBLE);
        }
    }

    public void jugarDeNuevo(View view) {
        puntuacion = 0;
        generarNAleatorio();
        cambiarBanderaYTexto();
        ib1.setVisibility(View.VISIBLE);
        ib2.setVisibility(View.VISIBLE);
        tvSelecciona.setVisibility(View.VISIBLE);
        bJugarDeNuevo.setVisibility(View.INVISIBLE);
    }

    private void restartApp() {
        System.exit(0);
    }

    private void cambiarBanderaYTexto() {
        ib1.setImageResource(banderas[nAleatorioBandera1]);
        ib2.setImageResource(banderas[nAleatorioBandera2]);
        tvSelecciona.setText("Selecciona la bandera de " + paises[banderaSeleccionada]);
        tvTuPuntuacion.setText("Tu puntuacion actual es " + puntuacion);
    }

    private void generarNAleatorio() {
        nAleatorioBandera1 = (int) (Math.random() * 4);
        nAleatorioBandera2 = (int) (Math.random() * 4);
        nAleatorioSeleccionaBandera = (int) (Math.random() * 2);
        if (nAleatorioBandera1 == nAleatorioBandera2)
            generarNAleatorio();

        if (nAleatorioSeleccionaBandera == 0)
            banderaSeleccionada = nAleatorioBandera1;
        else
            banderaSeleccionada = nAleatorioBandera2;
    }

}