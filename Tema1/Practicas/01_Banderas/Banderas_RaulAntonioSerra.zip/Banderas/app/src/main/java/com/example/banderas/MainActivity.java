package com.example.banderas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    int contador;
    int bandera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        randomFlag();
    }

    public void bandera1(View view) {
        comprobar(0);
        randomFlag();

    }

    public void bandera2(View view) {


        comprobar(1);
        randomFlag();

    }

    public void randomFlag(){
        Random randomNum = new Random();
        int[] banderas={R.drawable.china,R.drawable.eu,R.drawable.espana,R.drawable.japon};
        TextView campo=findViewById(R.id.textViewReglas);
        ImageButton[] botones= {findViewById(R.id.imageButtonBandera1), findViewById(R.id.imageButtonBandera2)};
        String[] texto={"Selecciona China","Selecciona Estados Unidos","Selecciona España","Selecciona Japon"};


        int random1 = randomNum.nextInt(4);
        int random2 = randomNum.nextInt(2);

        int random3= randomNum.nextInt(4);
        while (random1 == random3) {
            random3 = randomNum.nextInt(4);
        }
        bandera=0;
        if(random2==0){
            bandera=1;
        }
        botones[random2].setImageDrawable(getResources().getDrawable(banderas[random1]));
        botones[bandera].setImageDrawable(getResources().getDrawable(banderas[random3]));
        campo.setText(texto[random3]);

    }

    public void comprobar(int x){
        if(x==bandera){
            Toast.makeText(this, "+1 Punto", Toast.LENGTH_SHORT).show();
            contador++;
        }else{
            Toast.makeText(this, "Perdiste tenias "+contador+" puntos", Toast.LENGTH_SHORT).show();
            contador=0;
        }
    }

}