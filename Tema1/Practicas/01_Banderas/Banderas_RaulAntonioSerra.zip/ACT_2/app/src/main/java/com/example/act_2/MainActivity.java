package com.example.act_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = MainActivity.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) throws NullPointerException {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int[] bandera= {R.drawable.argentina,R.drawable.descarga, R.drawable.eeuu};
        assert false;
        AtomicInteger contador= new AtomicInteger();
        Random randomNum = new Random();

        int random1 = randomNum.nextInt(3);
        int random2 = randomNum.nextInt(3);
        while (random1 == random2) {
            random2 = randomNum.nextInt(3);
        }

        ImageButton band1=findViewById(R.id.btnBandera1);
        ImageButton band2=findViewById(R.id.btnBandera2);
        TextView TxtMensaje= findViewById(R.id.txtMensaje);
        int finalRandom = random2;
        band1.setOnClickListener(v -> {

            contador.addAndGet(1);
            band1.setBackgroundResource(bandera[random1]);
            band2.setBackgroundResource(bandera[finalRandom]);
            Log.i(TAG, "Las banderas han recibido un nuevo valor");
            switch (random1){
                case 0:
                    TxtMensaje.setText("Seleccione la bandera argentina");
                case 1:
                    TxtMensaje.setText("Seleccione la bandera de España");
                case 2:
                    TxtMensaje.setText("Seleccione la bandera de EEUU");
            }
        });
        band2.setOnClickListener(v -> {

            TxtMensaje.setText("Has perdido, tu puntuacion era de:"+contador);
            contador.set(0);
        });
    }
}