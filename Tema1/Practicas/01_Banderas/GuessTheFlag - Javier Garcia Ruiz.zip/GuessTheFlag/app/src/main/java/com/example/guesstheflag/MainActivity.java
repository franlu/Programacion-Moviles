package com.example.guesstheflag;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    int[] banderas = {
            R.drawable.spain,
            R.drawable.italy,
            R.drawable.germany,
            R.drawable.sanmarino
    };
    int i = 0;
    int correctId;
    int intR1, intR2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        generateNewFlags();

    }

    public void onClick(View view){
        if(view.getId() == R.id.imgBtn1){
            i++;
            generateNewFlags();
        }

    }

    public void generateNewFlags(){
        generateNewRandomFlag();
        ImageButton btn1 = findViewById(R.id.imgBtn1);
        ImageButton btn2 = findViewById(R.id.imgBtn2);

        btn1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Toast.makeText(MainActivity.this, "btn1 -> " + intR1 + "/ btn2 -> "+intR2 , Toast.LENGTH_SHORT).show();
                generateNewRandomFlag();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Toast.makeText(MainActivity.this, "btn1 -> " + intR1 + "/ btn2 -> "+intR2 , Toast.LENGTH_SHORT).show();
                generateNewRandomFlag();
            }
        });

    }

    public void generateNewRandomFlag(){

        intR1 = new Random().nextInt((3 - 0) + 1) ;
        intR2 = new Random().nextInt((3 - 0) + 1) ;

        while (intR1 == intR2){
            intR2 = new Random().nextInt((3 - 0) + 1) ;
        }

        generateNewFlags();
    }
}