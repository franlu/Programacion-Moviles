package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;


public class MainActivity extends AppCompatActivity {

    int contador=0;
    int r1,r2;
    String banderaBuena= "";

    String[] pais ={"Argentina","España","Italia","Brasil","Paraguay","Francia","Mexico","Polonia"};
    int[] bandera={R.drawable.arg, R.drawable.esp, R.drawable.ita, R.drawable.bra, R.drawable.par, R.drawable.fra, R.drawable.mex, R.drawable.pol};

    private ImageButton b1, b2;
    private TextView enseñaOpcion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        generarBandera();

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               comprobarBandera(r1);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comprobarBandera(r2);
            }
        });
    }
    public void generarBandera(){
        Random r= new Random();
        r1 =r.nextInt(8);
        r1=r.nextInt(8);

        while (r1 == r2){
            r2 = r.nextInt(8);
        }
        b1 = findViewById(R.id.imagenBandera1);
        b2 = findViewById(R.id.imagenBandera2);
        enseñaOpcion = findViewById(R.id.textoBandera);

        int[] ganar ={r1,r2};
        int esB = r.nextInt(ganar.length);

        banderaBuena = pais[ganar[esB]];

        b1.setImageResource(bandera[r1]);
        b2.setImageResource(bandera[r2]);
        enseñaOpcion.setText(banderaBuena);
    }
    public void comprobarBandera(int n){
        if(banderaBuena == pais[n]){
            contador +=1;
            generarBandera();;
            Toast.makeText(getApplicationContext(),"Correcto",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(),"Se acabo has obtenido estos puntos: "+contador,Toast.LENGTH_SHORT).show();
            contador=0;
        }
    }
}