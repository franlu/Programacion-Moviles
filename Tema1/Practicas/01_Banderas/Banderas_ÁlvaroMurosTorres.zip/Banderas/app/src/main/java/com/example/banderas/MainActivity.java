package com.example.banderas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button btn_generator;
    TextView edt_aleatorio;

    int puntos=0;
    private String banderas [] ={
            "españa",
            "eeuu",
            "portugal",
            "francia"
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton eeuu=findViewById(R.id.btnEEUU);

        ImageButton españa=findViewById(R.id.btnES);

        ImageButton portugal=findViewById(R.id.btnP);

        ImageButton francia=findViewById(R.id.btnF);

        btn_generator = (Button)findViewById(R.id.btngen);
        edt_aleatorio = (TextView) findViewById(R.id.TxtAleatorio);

        //TextView punto = findViewById(R.id.txt);

        btn_generator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random rand = new Random();
                int bandera = rand.nextInt(4);
                edt_aleatorio.setText(banderas[bandera]);

                if(eeuu == edt_aleatorio.getText()){
                    puntos +=1;
                }if (españa == edt_aleatorio.getText()){
                    puntos +=1;
                }if (portugal == edt_aleatorio.getText()){
                    puntos +=1;
                }if(francia == edt_aleatorio.getText()){
                    puntos +=1;
                }else{
                    puntos -=1;

                }

               // punto.setText(puntos);



            }
        });

    }
}