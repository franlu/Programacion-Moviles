package com.example.guesstheflag;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;
/*
*
*
* */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    int[] banderas = {
            R.drawable.spain,
            R.drawable.italy,
            R.drawable.germany,
            R.drawable.sanmarino
    };
    int i = 0;
    int correctId = 0;
    int intR1 = 0, intR2 = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        generateNewFlags();
    }
    @Override
    public void onClick(View view){
        if(view.getId() == R.id.imgBtn1){
            i++;
            generateNewFlags();
        }

    }

    public void generateNewFlags(){
        TextView txtCorrectFlag = findViewById(R.id.txtCorrectFlag);
        ImageButton btn1 = findViewById(R.id.imgBtn1);
        ImageButton btn2 = findViewById(R.id.imgBtn2);
        btn1.setImageResource(banderas[intR1]);
        btn2.setImageResource(banderas[intR2]);

        btn1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                generateNewRandomFlag();
                if(intR1 == correctId){
                    Toast.makeText(MainActivity.this, "Correcta", Toast.LENGTH_SHORT).show();
                    i++;

                }else{
                    Toast.makeText(MainActivity.this, "Has fallado, has conseguido " + i + " puntos. Intentalo de nuevo", Toast.LENGTH_SHORT).show();
                    i = 0;
                }
            }
        });

        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                generateNewRandomFlag();
                if(intR2 == correctId){
                    Toast.makeText(MainActivity.this, "Correcta", Toast.LENGTH_SHORT).show();
                    i++;

                }else{
                    Toast.makeText(MainActivity.this, "Has fallado, has conseguido " + i + " puntos. Intentalo de nuevo", Toast.LENGTH_SHORT).show();
                    i = 0;
                }
            }
        });

        switch (correctId){
            case 0:
                txtCorrectFlag.setText("España");
                break;
            case 1:
                txtCorrectFlag.setText("Italia");
                break;
            case 2:
                txtCorrectFlag.setText("Alemania");
                break;
            case 3:
                txtCorrectFlag.setText("San Marino");
                break;

        }

    }

    public void generateNewRandomFlag(){

        intR1 = new Random().nextInt((3 - 0) + 1) ;
        intR2 = new Random().nextInt((3 - 0) + 1) ;
        int tempCorrectId = new Random().nextInt((1 - 0)) ;
        switch(tempCorrectId){
            case 0:
                correctId = intR1;
                break;
            case 1:
                correctId = intR2;
                break;
        }

        while (intR1 == intR2){
            intR2 = new Random().nextInt((3 - 0) + 1) ;
        }
        Log.wtf("DEBUG ===>", intR1 + " - " + intR2 + " - " + correctId + " - " + tempCorrectId);
        generateNewFlags();
    }
}