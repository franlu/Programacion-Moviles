package com.example.banderas;



import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int contador = 0, ran1,ran2;
    private String banderabuena = "";
    private String[] paises = {"Argentina","España","Japón","Francia","Rusia"};
    private int[] banderas = {R.drawable.argentina,R.drawable.espana,R.drawable.japon,R.drawable.francia,R.drawable.rusia};

    private ImageButton bandera1, bandera2;
    private TextView opciones;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        generabandera();
        bandera1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comprobarBandera(ran1);
            }
        });
        bandera2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comprobarBandera(ran2);
            }
        });
    }
    public void generabandera(){
        Random r = new Random();
        ran1 = r.nextInt(5);
        ran2 = r.nextInt(5);

        while (ran1 == ran2) {
            ran2 = r.nextInt(5);
        }

        bandera1 = findViewById(R.id.imgbtnBandera1);
        bandera2 = findViewById(R.id.imgbtnBandera2);
        opciones = findViewById(R.id.txtBandera);

        int[] ganador = {ran1, ran2};
        int esBandera = r.nextInt(ganador.length);
        banderabuena = paises[ganador[esBandera]];

        bandera1.setImageResource(banderas[ran1]);
        bandera2.setImageResource(banderas[ran2]);
        opciones.setText(banderabuena);
    }

    public void comprobarBandera(int n){
        if (banderabuena == paises[n]){
            contador += 1;
            generabandera();
            Toast.makeText(getApplicationContext()
                    ,"Acierto"
                    ,Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext()
                    ,"Final del juego. su puntuación es: "+contador
                    ,Toast.LENGTH_SHORT).show();
            contador = 0;
        }
    }
}