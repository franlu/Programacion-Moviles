package com.example.sesion22;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.ImageButton;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;


public class MainActivity extends AppCompatActivity {

    int contador=0,rInt,rInt2;
    ImageButton btnUp;
    ImageButton btnDown;
    TextView txtSelec;
    int [] banderas = {R.drawable.alemania,R.drawable.colombia,
            R.drawable.francia,R.drawable.bandera_nacional_de_espa_a,R.drawable.usa};
    String [] nombres = {"Alemania", "Colombia", "Francia", "España", "Estados Unidos"};
    String bandElegida;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        generacionBanderas();
        btnUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comprobarBandera(rInt);
            }
        });
        btnDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comprobarBandera(rInt2);
            }
        });

    }

    public void generacionBanderas(){
        Random r = new Random();
        rInt = r.nextInt(3);
        rInt2 = r.nextInt(3);

        if (rInt == rInt2){
            rInt = r.nextInt();
        }

        btnUp= (ImageButton)findViewById(R.id.btnUp);
        btnDown = (ImageButton)findViewById(R.id.btnDown);
        txtSelec = (TextView)findViewById(R.id.txtSelec);

        int[] banderaGanadora = {rInt, rInt2};
        int seleccionador = r.nextInt(banderaGanadora.length);
        bandElegida = nombres[banderaGanadora[seleccionador]];

        btnUp.setImageResource(banderas[rInt]);
        btnDown.setImageResource(banderas[rInt2]);
        txtSelec.setText(bandElegida);
    }

    public void comprobarBandera(int n){
        if (bandElegida == nombres[n]){
            contador += 1;
            generacionBanderas();
            Toast.makeText(getApplicationContext()
                    ,"Bandera correcta. Lleva  " + contador + " puntos"
                    ,Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext()
                    ,"Fin del intento. Puntuación: "+contador
                    ,Toast.LENGTH_SHORT).show();
            contador = 0;

        }
    }

}
