package com.example.flagsgame;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Random;

public class MainActivity extends AppCompatActivity /* implements View.OnClickListener*/{

    int[] flags = new int[]{R.drawable.ad,R.drawable.al,R.drawable.ar,R.drawable.bt} ;
    int[] flagsName = {R.string.ad,R.string.al,R.string.ar,R.string.bt};
    int[] randNums =new int[2];
    int[] textSelected = new int[2];
    Random rand = new Random(); //instance of random class
    int upperbound = 4;
    int randButton;
    int puntos = 0;

    //generate random values from 0-24
     //rand.nextInt(upperbound);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createStage();
    }

    protected void createStage(){
        int temp = 0;
        for(int i=0; i<2; i++){
            int randnum = rand.nextInt(upperbound);
            if(i>=1&&randnum==temp)i--;
            textSelected[i] = randnum;
            temp=randnum;
            randNums[i]= flags[randnum];
        }


        ImageButton[] buttons = {findViewById(R.id.btn1),findViewById(R.id.btn2)};


        for (int i = 0; i<buttons.length; i++){
            buttons[i].setImageDrawable(getResources().getDrawable(randNums[i]));
        }

        TextView points = findViewById(R.id.points);
        points.setText(getString(R.string.points)+" "+puntos);

        TextView tv = findViewById(R.id.msg);
        upperbound = buttons.length;
        randButton = rand.nextInt(upperbound);
        tv.setText(getString(R.string.msg_init)+" "+getString(flagsName[textSelected[randButton]]));
    }



    public void onClick(View view) {
        if(view.getId()==R.id.btn1){
            if(textSelected[randButton]==textSelected[0]){
                Toast.makeText(this, "Acertaste +1 punto", Toast.LENGTH_SHORT).show();
                puntos++;
                createStage();
            }else{
                puntos=0;
                Toast.makeText(this, "PERDISTE", Toast.LENGTH_SHORT).show();
                createStage();
            }
        }else if(view.getId()==R.id.btn2){
            if(textSelected[randButton]==textSelected[1]){
                Toast.makeText(this, "Acertaste +1 punto", Toast.LENGTH_SHORT).show();
                puntos++;
                createStage();
            }else{
                puntos=0;
                Toast.makeText(this, "PERDISTE", Toast.LENGTH_SHORT).show();
                createStage();
            }
        }

    }
}