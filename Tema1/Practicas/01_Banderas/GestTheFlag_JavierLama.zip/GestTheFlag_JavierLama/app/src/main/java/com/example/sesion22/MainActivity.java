package com.example.sesion22;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.ImageButton;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{


    ImageButton btnUp;
    ImageButton btnDown;
    ImageButton btnText;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnUp= (ImageButton)findViewById(R.id.btnUp);
        btnUp.setOnClickListener(this);
        btnDown = (ImageButton)findViewById(R.id.btnDown);
        btnDown.setOnClickListener(this);
        btnText = (ImageButton)findViewById(R.id.btnText);
        btnText.setOnClickListener(this);

    }
    int contador = 0;
    public void onClick(View v) {
        Random r = new Random();
        Random r2 = new Random();

        int rInt = r.nextInt(4);
        int rInt2 = r2.nextInt(4);
        int [] banderas = {R.drawable.alemania,R.drawable.colombia,
                R.drawable.francia,R.drawable.bandera_nacional_de_espa_a,R.drawable.usa};

        int randomBandera = r.nextInt(2);
        if (randomBandera == 1){
            btnText.setImageResource(banderas[rInt]);
        }else{
            btnText.setImageResource(banderas[rInt2]);
        }


        btnUp.setImageResource(banderas[rInt]);
        btnDown.setImageResource(banderas[rInt2]);

        contador++;
        Toast.makeText(getApplicationContext(),
                "Puntuación: "+ contador
                ,Toast.LENGTH_SHORT).show();



    }

}
