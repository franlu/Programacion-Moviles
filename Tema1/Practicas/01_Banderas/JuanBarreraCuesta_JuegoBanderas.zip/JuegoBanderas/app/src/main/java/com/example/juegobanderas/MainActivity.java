package com.example.juegobanderas;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/*
* @author Acaluw
* */

public class MainActivity extends AppCompatActivity {

    private int cuentaPuntos = 0, ran1,ran2;
    private String banderaGanadora = "";

    private String[] paises = {"Argentina","España","Japón","Corea","Rusia"};
    private int[] banderas = {R.drawable.argentina,R.drawable.espana,R.drawable.japon,R.drawable.corea,R.drawable.rusia};

    private ImageButton bandera1, bandera2;
    private TextView muestraOpcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        generaBanderas();

        bandera1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comprobarBandera(ran1);
            }
        });
        bandera2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comprobarBandera(ran2);
            }
        });
    }

    public void generaBanderas(){
        Random r = new Random();
        ran1 = r.nextInt(5);
        ran2 = r.nextInt(5);

        while (ran1 == ran2) {
            ran2 = r.nextInt(5);
        }

        bandera1 = findViewById(R.id.imgbtnBandera1);
        bandera2 = findViewById(R.id.imgbtnBandera2);
        muestraOpcion = findViewById(R.id.txtBandera);

        int[] ganador = {ran1, ran2};
        int esBandera = r.nextInt(ganador.length);
        banderaGanadora = paises[ganador[esBandera]];

        bandera1.setImageResource(banderas[ran1]);
        bandera2.setImageResource(banderas[ran2]);
        muestraOpcion.setText(banderaGanadora);
    }

    public void comprobarBandera(int n){
        if (banderaGanadora == paises[n]){
            cuentaPuntos += 1;
            generaBanderas();
            Toast.makeText(getApplicationContext()
                    ,"Correcto"
                    ,Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext()
                    ,"Fin del juego. Puntuación: "+cuentaPuntos
                    ,Toast.LENGTH_SHORT).show();
            cuentaPuntos = 0;
        }
    }
}