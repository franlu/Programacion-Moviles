package com.example.banderas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = MainActivity.class.getSimpleName();

    Button botonbanderas;
    boolean banderaboton;


    int [] banderas= new int[]{R.drawable.spain, R.drawable.uruguay, R.drawable.japan, R.drawable.germany};

    @Override
    public void onClick(View view) {
        TextView mensaje = findViewById(R.id.textView);
        mensaje.setText("He pulsado el botón");
        Log.i(TAG, "Se ha ejecutado el método OnClick");
        Toast.makeText(this, "Texto rojo", Toast.LENGTH_LONG).show();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        ImageButton boton1, boton2;
        boton1=findViewById(banderas[1]);
        boton2 =findViewById(banderas[2]);



    }
}