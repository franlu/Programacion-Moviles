package com.example.examen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView v = findViewById(R.id.textView2);
        v.setText("");

    }

    @Override
    public void onClick(View view) {
        TextView username = findViewById(R.id.editTextTextPersonName);
        TextView username2 = findViewById(R.id.editTextTextPersonName2);
        TextView v = findViewById(R.id.textView2);
        System.out.println("----->"+username.getText()+"<------");
        if(username.getText().length()==0 || username2.getText().length()==0){
            v.setText(R.string.params);
        }else{
            Intent intent = new Intent(this, SecondaryActivity.class);
            intent.putExtra("user", username.getText());
            intent.putExtra("user2", username2.getText());
            startActivityForResult(intent, R.layout.activity_secondary);
        }
    }
}