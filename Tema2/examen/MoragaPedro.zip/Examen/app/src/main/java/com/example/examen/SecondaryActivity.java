package com.example.examen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class SecondaryActivity extends AppCompatActivity implements View.OnClickListener{

    int pos = 0;
    String[] users = new String[2];
    TextView textview;
    String turn;
    int start = 0;
    int[] ids = new int[9];
    String[] colors = new String[9];


    //android:src="@android:drawable/ic_delete" Equis
    //android:src="@android:drawable/ic_input_add" Cruz

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary);
        Bundle bundle = new Bundle();
        users[0] = bundle.getString("user");
        users[1] = bundle.getString("user2");
        textview= findViewById(R.id.textView3);
        turn = (String) textview.getText();
        textview.setText(turn+" ----> "+users[0]);
    }

    @Override
    public void onClick(View view) {
        if(pos == 0) pos++;
        else pos--;
        ImageButton btn;
        btn = findViewById(view.getId());
        if(pos == 0)btn.setImageDrawable(getDrawable(R.drawable.redcircle));
        else btn.setImageDrawable(getDrawable(R.drawable.bluecircle));
        btn.setEnabled(false);
        textview.setText(turn+" ----> "+users[pos]);

        //System.out.println(pos == 1 ? "Azul" + " Botón: " +btn.getId() : "Rojo" + " Botón: " +btn.getId());
        //id es la posición
        ids[start] = btn.getId();
        for (int i = 0; i<ids.length; i++) System.out.print(ids[i]+" ");
        System.out.println("\n");
        colors[start] = pos == 1 ?  "Azul" : "Rojo";
        for (int i = 0; i<colors.length; i++) System.out.print(colors[i]+" ");
        start++;
        if (ids[ids.length-1]!=0) textview.setText(getResources().getString(R.string.draw).toString());
    }

    public void extra(View view){
        switch (view.getId()){
            case R.id.floatingActionButton:
                Intent intent = new Intent(this, HelpActivity.class);
                startActivityForResult(intent, R.layout.activity_help);
                break;
            case R.id.floatingActionButton2:
                Intent intent2 = new Intent(this, InfoActivity.class);
                startActivityForResult(intent2, R.layout.activity_info);
                break;
        }
    }
}