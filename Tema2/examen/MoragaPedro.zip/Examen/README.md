# Examen
Juego de 3 en raya de 2 jugadores en local

**Ejemplo**

Ejemplo de como se ve el juego

![image](https://i.imgur.com/nl07HC4.png)

**Registro**

Registro de los usuarios que van a jugar

![image](https://i.imgur.com/AjUxFwg.png)

**Ayuda**

Información acerca de como jugar al juego

![image](https://i.imgur.com/qtr43Iw.png)

**Información**

Información acerca del desarrollador del juego

![image](https://i.imgur.com/n1Nh2ak.png)