package com.example.juego;

public class MainActivity2 {
}
