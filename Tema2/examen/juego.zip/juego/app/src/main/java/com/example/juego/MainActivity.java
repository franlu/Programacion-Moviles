package com.example.juego;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button Registrar = findViewById(R.id.button1);
        Button Acerca_de = findViewById(R.id.button2);
        Button instrucciones = findViewById(R.id.button3);
        TextView nombre = findViewById(R.id.nombre);
        TextView contraseña = findViewById(R.id.contraseña);








    }
}

