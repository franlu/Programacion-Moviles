package com.example.examenandroid;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Random;

public class GameActivity extends AppCompatActivity {

    AlertDialog.Builder dialog;
    int i, j;
    int iaRow, iaCol;
    ImageButton[][] buttons;
    boolean[][] checker = {
            {false, false, false},
            {false, false, false},
            {false, false, false}
    };
    char[][] win = {
            {'w', 'w', 'w'},
            {'w', 'w', 'w'},
            {'w', 'w', 'w'}
    };

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Bundle b = getIntent().getExtras();
        String user = b.getString("user");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        TextView txt = findViewById(R.id.txtUserLogged);
        txt.setText("Usuario: " + user);
        ImageButton[][] gameField = {
                {
                    findViewById(R.id.btn1_1),findViewById(R.id.btn1_2),findViewById(R.id.btn1_3)
                },
                {
                    findViewById(R.id.btn2_1),findViewById(R.id.btn2_2),findViewById(R.id.btn2_3)
                },
                {
                    findViewById(R.id.btn3_1),findViewById(R.id.btn3_2),findViewById(R.id.btn3_3)
                }
        };

        buttons = gameField;

        for(i = 0; i < 3; i++){
            Arrays.stream(gameField[i]).sequential().forEach(btn -> btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    for(int i = 0; i < 3; i++){
                        for(int j = 0; j < 3; j++){
                            if(view.getId() == gameField[i][j].getId()){
                                if(!checker[i][j]){
                                    gameField[i][j].setImageResource(R.drawable.x);
                                    checker[i][j] = true;
                                    win[i][j] = 'x';
                                    checkWin('x');
                                    newIAValue();
                                }
                            }
                        }
                    }
                }
            }));
        }
    }

    public void newIAValue(){
        Thread t = new Thread(() -> {

            boolean whileTrue = true;
            while(whileTrue){
                int counter = 0;
                iaRow = new Random().nextInt(3);
                iaCol = new Random().nextInt(3);
                if(counter < 8){
                    if(!checker[iaRow][iaCol]){
                        buttons[iaRow][iaCol].setImageResource(R.drawable.o);
                        checker[iaRow][iaCol] = true;
                        win[iaRow][iaCol] = 'o';
                        whileTrue = false;
                    }else{
                        counter++;
                        Toast.makeText(this, "Terminó la partida", Toast.LENGTH_SHORT).show();
                        whileTrue = false;

                    }
                }
            }
            checkWin('o');
        });
        t.run();
    }

    public void checkWin(char player){
        if(win[0][0] == player && win[0][1] == player && win[0][2] == player){
            Toast.makeText(this, player=='x' ? "Ganaste!" : "Perdiste", Toast.LENGTH_SHORT).show();
        }
        if(win[0][0] == player && win[1][1] == player && win[2][2] == player){
            Toast.makeText(this, player=='x' ? "Ganaste!" : "Perdiste", Toast.LENGTH_SHORT).show();
        }
        if(win[0][2] == player && win[1][1] == player && win[2][0] == player){
            Toast.makeText(this, player=='x' ? "Ganaste!" : "Perdiste", Toast.LENGTH_SHORT).show();
        }
        if(win[1][0] == player && win[1][1] == player && win[1][2] == player){
            Toast.makeText(this, player=='x' ? "Ganaste!" : "Perdiste", Toast.LENGTH_SHORT).show();
        }
        if(win[2][0] == player && win[2][1] == player && win[2][2] == player){
            Toast.makeText(this, player=='x' ? "Ganaste!" : "Perdiste", Toast.LENGTH_SHORT).show();
        }
        if(win[0][0] == player && win[1][0] == player && win[2][0] == player){
            Toast.makeText(this, player=='x' ? "Ganaste!" : "Perdiste", Toast.LENGTH_SHORT).show();
        }
        if(win[0][1] == player && win[1][1] == player && win[2][1] == player){
            Toast.makeText(this, player=='x' ? "Ganaste!" : "Perdiste", Toast.LENGTH_SHORT).show();
        }
        if(win[0][2] == player && win[1][2] == player && win[2][2] == player){
            Toast.makeText(this, player=='x' ? "Ganaste!" : "Perdiste", Toast.LENGTH_SHORT).show();
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    };

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()) {
            case R.id.miAcerca:
                Toast.makeText(this, "Aplicacion hecha por Javier Garcia", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.miInstrucciones:
                Intent i = new Intent(this.getBaseContext(), GameActivity.class);
                startActivity(i);
                return true;
            case R.id.miSalir:
                ThrowDialog();
                return true;
            default:
                return true;
        }
    }
    public void ThrowDialog(){
        dialog = new AlertDialog.Builder(GameActivity.this);
        dialog.setTitle("Has Terminado");
        dialog.setMessage("¿Quieres salir?");

        dialog.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo, int id) {
                dialogo.cancel();
            }
        });
        dialog.setNegativeButton("No, Salir", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo, int id) {
                finish();
            }
        });
        dialog.show();
    }
}