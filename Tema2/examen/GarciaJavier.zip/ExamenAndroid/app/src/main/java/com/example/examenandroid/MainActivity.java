package com.example.examenandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    //Global Variables
    String user = "player", pass = "player";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Items
        Button btn = findViewById(R.id.btnLogin);

        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        EditText inputUser = findViewById(R.id.txtUser);
        EditText inputPass = findViewById(R.id.txtPass);

        if(inputUser.getText().toString().length() == 0 || inputPass.getText().toString().length() == 0){
            Toast.makeText(this, "Uno de los campos del Login no esta relleno", Toast.LENGTH_SHORT).show();
        }else{
            if(user.equals(inputUser.getText().toString()) && pass.equals(inputPass.getText().toString())){
                Intent i = new Intent(view.getContext(), GameActivity.class);
                i.putExtra("user", user);

                startActivityForResult(i, 0);
            }else{
                Toast.makeText(this, "Las credenciales no son validas, vuelve a intentarlo"
                                    , Toast.LENGTH_SHORT).show();
            }
        }
    }
}