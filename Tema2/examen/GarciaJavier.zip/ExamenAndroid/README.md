## ExamenAndroid

### Por Javier García Ruiz

Vamos a crear un Tres en Raya para Android. Para ello, vamos a crear un pequeño login, usando credenciales ya creadas con anterioridad.

Usaremos unas credenciales básicas como prueba
```
player:player
```

Cuando las credenciales no sean válidas, usaré un Toast para notificar que no ha sido posible el acceso

Para el funcionamiento del juego, he diseñado un Array Bidimensional de ImageButton, imitando un tablero 3X3.

Para marcar una casilla, he usado On Click Listeners anonimos para mayor sencillez.

Para aplicar los onClick listeners de forma simultanea a todos los botones he usado programacion funcional con una expresion Lambda 
`Arrays.stream(gameField[i]).sequential().foreach(btn -> btn.setOnClickListener());`

Para identificar a cada jugador de la partida, se le ha asignado una ficha en forma de char. ('x' y 'o')

Para la casilla que juega la IA, he diseñado una funcion la cual, usando 2 arrays bidimensionales identifica cuales casillas estan libres y cuales no, y sobre las que estan libres, poner su ficha.

`newIAValue(char ficha)`

Para cubrir las condiciones de victoria del juego Tres en Raya, he creado una función la cual, pasandole la ficha.

![WinConditions](wincondition.png)

Para poder ver las instrucciones del juego y un poco de informacion de la aplicacion he creado un menú donde abre una nueva actividad con las instrucciones del juego.
Dentro del menú tambien hay una opcion de Salir que nos saca un Dialog donde nos pregunta si queremos salir.

