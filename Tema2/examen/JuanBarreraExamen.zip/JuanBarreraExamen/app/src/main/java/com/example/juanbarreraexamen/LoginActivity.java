package com.example.juanbarreraexamen;
/**
 * @author Juan Barrera Cuesta 2ºDAM
 */

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    EditText nickname;
    Button play;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        nickname = findViewById(R.id.editTextNickname);
        play = findViewById(R.id.btnPlay);

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String playerNick = nickname.getText().toString();

                if(playerNick.length()>7 || playerNick.length()==0){
                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                    builder.setTitle("Error de nickname");
                    builder.setMessage("Longitud de nickname no válida. (Nickname >0 y <=7)");

                    builder.setPositiveButton("ACEPTAR", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                        }
                    });
                    builder.show();
                }else{
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    intent.putExtra("nickname",playerNick);
                    startActivityForResult(intent,0);
                    finish();
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuAbout:
                Intent intentA = new Intent(getApplicationContext(), AboutActivity.class);
                startActivity(intentA);
                return true;
            case R.id.menuInstruc:
                Intent intentB = new Intent(getApplicationContext(), InstructionActivity.class);
                startActivity(intentB);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}