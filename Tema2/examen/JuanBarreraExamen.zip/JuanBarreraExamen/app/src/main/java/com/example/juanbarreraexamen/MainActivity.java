package com.example.juanbarreraexamen;
/**
 * @author Juan Barrera Cuesta 2ºDAM
 */

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    TextView player;
    Button[] pos = new Button[9];
    boolean seguir = true;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent bundle = getIntent();
        String nick = bundle.getStringExtra("nickname");

        player = findViewById(R.id.txtPlayer);
        player.setText(nick);

        pos[0] = findViewById(R.id.btPos1);
        pos[1] = findViewById(R.id.btPos2);
        pos[2] = findViewById(R.id.btPos3);
        pos[3] = findViewById(R.id.btPos4);
        pos[4] = findViewById(R.id.btPos5);
        pos[5] = findViewById(R.id.btPos6);
        pos[6] = findViewById(R.id.btPos7);
        pos[7] = findViewById(R.id.btPos8);
        pos[8] = findViewById(R.id.btPos9);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuAbout:
                Intent intentA = new Intent(getApplicationContext(), AboutActivity.class);
                startActivity(intentA);
                return true;
            case R.id.menuInstruc:
                Intent intentB = new Intent(getApplicationContext(), InstructionActivity.class);
                startActivity(intentB);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void dibuja(View view){
        Handler handler = new Handler();
        Button choose = findViewById(view.getId());

        if(comprobarHuecos()){
            if(!choose.getText().toString().equals("O")){
                choose.setText("X");
                choose.setEnabled(false);
                comprobarGanador();
                if(seguir) {
                    handler.postDelayed(() -> {
                        mueveBot();
                    }, 500);
                }
            }
        }else{
            empate();
        }
    }

    public void mueveBot(){
        boolean bucle = true;
        if(comprobarHuecos()){
            do{
                int r = new Random().nextInt(9);
                if(!pos[r].getText().toString().equals("X") && !pos[r].getText().toString().equals("O")){
                    pos[r].setText("O");
                    pos[r].setEnabled(false);
                    bucle = false;
                }
            }while(bucle);
            comprobarGanador();
        }else{
            empate();
        }
    }

    public boolean comprobarHuecos(){
        int contador = 0;
        for(int i=0; i<pos.length; i++){
            if(pos[i].getText().toString().equals("")){
                contador+=1;
            }
        }

        if(contador>0){
            return true;
        }else{
            return false;
        }
    }

    public void empate(){
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("EMPATE");
        builder.setMessage("Ha habido un empate");

        builder.setPositiveButton("TERMINAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                dialogInterface.cancel();
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("REINICIAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                reinicio();
                dialogInterface.cancel();
            }
        });
        builder.show();
    }

    public void comprobarGanador(){
        //Caso 1º linea horizontal
        if(getButtonText(pos[0]).equals("X") && getButtonText(pos[1]).equals("X") && getButtonText(pos[2]).equals("X")){
            ganador(player.getText().toString());
            seguir = false;
        }else if(getButtonText(pos[0]).equals("O") && getButtonText(pos[1]).equals("O") && getButtonText(pos[2]).equals("O")){
            ganador("IA");
        }
        //Caso 2º linea horizontal
        if(getButtonText(pos[3]).equals("X") && getButtonText(pos[4]).equals("X") && getButtonText(pos[5]).equals("X")){
            ganador(player.getText().toString());
            seguir = false;
        }else if(getButtonText(pos[3]).equals("O") && getButtonText(pos[4]).equals("O") && getButtonText(pos[5]).equals("O")){
            ganador("IA");
        }
        //Caso 3º linea horizontal
        if(getButtonText(pos[6]).equals("X") && getButtonText(pos[7]).equals("X") && getButtonText(pos[8]).equals("X")){
            ganador(player.getText().toString());
            seguir = false;
        }else if(getButtonText(pos[6]).equals("O") && getButtonText(pos[7]).equals("O") && getButtonText(pos[8]).equals("O")){
            ganador("IA");
        }

        //Caso 1º linea vertical
        if(getButtonText(pos[0]).equals("X") && getButtonText(pos[3]).equals("X") && getButtonText(pos[6]).equals("X")){
            ganador(player.getText().toString());
            seguir = false;
        }else if(getButtonText(pos[0]).equals("O") && getButtonText(pos[3]).equals("O") && getButtonText(pos[6]).equals("O")){
            ganador("IA");
        }
        //Caso 2º linea vertical
        if(getButtonText(pos[1]).equals("X") && getButtonText(pos[4]).equals("X") && getButtonText(pos[7]).equals("X")){
            ganador(player.getText().toString());
            seguir = false;
        }else if(getButtonText(pos[1]).equals("O") && getButtonText(pos[4]).equals("O") && getButtonText(pos[7]).equals("O")){
            ganador("IA");
        }
        //Caso 3º linea vertical
        if(getButtonText(pos[2]).equals("X") && getButtonText(pos[5]).equals("X") && getButtonText(pos[8]).equals("X")){
            ganador(player.getText().toString());
            seguir = false;
        }else if(getButtonText(pos[2]).equals("O") && getButtonText(pos[5]).equals("O") && getButtonText(pos[8]).equals("O")){
            ganador("IA");
        }

        //Caso diagonal 1
        if(getButtonText(pos[0]).equals("X") && getButtonText(pos[4]).equals("X") && getButtonText(pos[8]).equals("X")){
            ganador(player.getText().toString());
            seguir = false;
        }else if(getButtonText(pos[0]).equals("O") && getButtonText(pos[4]).equals("O") && getButtonText(pos[8]).equals("O")){
            ganador("IA");
        }
        //Caso diagonal 2
        if(getButtonText(pos[2]).equals("X") && getButtonText(pos[4]).equals("X") && getButtonText(pos[6]).equals("X")){
            ganador(player.getText().toString());
            seguir = false;
        }else if(getButtonText(pos[2]).equals("O") && getButtonText(pos[4]).equals("O") && getButtonText(pos[6]).equals("O")){
            ganador("IA");
        }
    }

    public String getButtonText(Button b){
        return b.getText().toString();
    }

    public void ganador(String w){
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Ganador");
        builder.setMessage("El jugador: "+w+" ha ganado la partida.");

        builder.setPositiveButton("TERMINAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                dialogInterface.cancel();
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("REINICIAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                reinicio();
                dialogInterface.cancel();
            }
        });
        builder.show();
    }

    public void reinicio(){
        for(int i=0; i<pos.length; i++){
            pos[i].setText("");
            pos[i].setEnabled(true);
        }
        seguir = true;
    }
}