package com.example.examenandroid;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editTxtUser;
    Button btnEntrar, btnAyuda;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnEntrar = findViewById(R.id.buttonEntrar);
        btnAyuda = findViewById(R.id.buttonAyuda);
        editTxtUser = findViewById(R.id.editTextUsuario);


        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editTxtUser.getText().equals("")){
                    Toast.makeText(MainActivity.this, "El usuario no puede estar vacio", Toast.LENGTH_SHORT).show();
                }else{
                    Intent intent = new Intent (view.getContext(), JuegoActivity.class);
                    intent.putExtra("usuario", editTxtUser.getText().toString());
                    startActivityForResult(intent, 0);

                }
            }
        });

        btnAyuda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (view.getContext(), AyudaActivity.class);
                startActivityForResult(intent, 0);

            }
        });


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mItemAcerca:
                Toast.makeText(this, "Creado por Jose Antonio Orellano Gómez", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}