package com.example.examenandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class JuegoActivity extends AppCompatActivity {

    TextView txtNombre;
    ImageButton imgBtn1, imgBtn2, imgBtn3, imgBtn4, imgBtn5, imgBtn6, imgBtn7, imgBtn8, imgBtn9;

    ImageButton imgBtns [] = new ImageButton[]{
            imgBtn1, imgBtn2, imgBtn3, imgBtn4, imgBtn5, imgBtn6, imgBtn7, imgBtn8, imgBtn9
    };

    int drawable [] = new int[]{R.drawable.equis, R.drawable.circulo};
    int botonesActivados [] = new int[10];
    int contadorBotonesActivados = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);

        txtNombre = findViewById(R.id.textViewNombre);

        Bundle bundle = getIntent().getExtras();
        String usuario = bundle.getString("usuario");
        txtNombre.setText(usuario);

        imgBtns[0] = findViewById(R.id.imageButton1);
        imgBtns[1] = findViewById(R.id.imageButton2);
        imgBtns[2] = findViewById(R.id.imageButton3);
        imgBtns[3] = findViewById(R.id.imageButton4);
        imgBtns[4] = findViewById(R.id.imageButton5);
        imgBtns[5] = findViewById(R.id.imageButton6);
        imgBtns[6] = findViewById(R.id.imageButton7);
        imgBtns[7] = findViewById(R.id.imageButton8);
        imgBtns[8] = findViewById(R.id.imageButton9);


        imgBtns[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toqueMio(0);
            }
        });

        imgBtns[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toqueMio(1);
            }
        });

        imgBtns[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toqueMio(2);
            }
        });

        imgBtns[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toqueMio(3);
            }
        });

        imgBtns[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toqueMio(4);
            }
        });

        imgBtns[5].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toqueMio(5);
            }
        });

        imgBtns[6].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toqueMio(6);
            }
        });

        imgBtns[7].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toqueMio(7);
            }
        });

        imgBtns[8].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toqueMio(8);
            }
        });
    }

    public void toqueMio(int id){
        imgBtns[id].setImageResource(drawable[1]);
        imgBtns[id].setEnabled(false);
        botonesActivados[contadorBotonesActivados] = id;
        contadorBotonesActivados++;

        //toqueRival();
    }

    public void toqueRival(){
        Random r = new Random();
        Boolean rep = true;
        Boolean estaActivado = false;
        int nAleatorio = 0;
        while(rep){

            nAleatorio = r.nextInt(9);

            for (int i = 0; i < botonesActivados.length; i++){
                if (nAleatorio == botonesActivados[i]){
                    estaActivado = true;
                }
            }
            if (!estaActivado){
                botonesActivados[contadorBotonesActivados] = nAleatorio;
                contadorBotonesActivados++;
                rep = false;
            }
        }

        imgBtns[nAleatorio].setImageResource(drawable[0]);
        imgBtns[nAleatorio].setEnabled(false);
        Toast.makeText(this, botonesActivados[0]+" "+botonesActivados[1]+" "+botonesActivados[2]+" "+botonesActivados[3]+" "+botonesActivados[4]+" "+botonesActivados[5]+" "+botonesActivados[6]+" "+botonesActivados[7], Toast.LENGTH_SHORT).show();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mItemAcerca:
                Toast.makeText(this, "Creado por Jose Antonio Orellano Gómez", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}