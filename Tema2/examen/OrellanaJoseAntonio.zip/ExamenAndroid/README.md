# Tres en raya by Jose A. Orellana Gómez
Para empezar tenemos el menu de inicio el cual esta compuesto por:
1 Imagen en grande.
1 EditText para insertar el usuario
2 Botones, uno para entrar al juego y otro para ir a la pantalla de ayuda

![image](https://user-images.githubusercontent.com/101654298/202519226-576cec0a-433f-4ab4-964d-227dff9421d3.png)

La pantalla del juego esta compuesta por 9 imageButtons y 1 TextView con el nombre de usuario que nos pusimos antes.

![image](https://user-images.githubusercontent.com/101654298/202519490-c941654d-081c-45a9-9782-25a287eadf01.png)

Por ultimo tenemos la pantalla de ayuda donde solo hay 3 textviews y 1 button para volver atras.

![image](https://user-images.githubusercontent.com/101654298/202519726-fd299170-71bb-402b-be8c-47a6856c5eea.png)

Todas las pantallas tienen un option menu con una unica opcion llamada "acerca de" que al pulsarlo nos salta un mensaje con el siguiente mensaje "Creado por Jose..."
