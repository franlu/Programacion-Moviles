package com.example.yanyulei_examen_pdm;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.yanyulei_examen_pdm.databinding.ActivityJuegoBinding;

import java.util.List;

public class JuegoActivity extends AppCompatActivity implements View.OnClickListener {

    ActivityJuegoBinding b;

    int puntuacionX, puntuacionO;
    boolean esX, turnoX;
    String sPuntuacionDe, sPuntuacionX, sPuntuacionO, sNombreX, sNombreO;
    String[] opciones;

    List<Button> buttons;

    AlertDialog.Builder adBuilder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);
        b = ActivityJuegoBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());

        puntuacionX = 0;
        puntuacionO = 0;

        esX = true;
        turnoX = true;

        Intent intentLogin = getIntent();

        sNombreX = intentLogin.getStringExtra("nombreX");
        sNombreO = intentLogin.getStringExtra("nombreO");

        sPuntuacionDe = getString(R.string.PuntuacionDe);
        sPuntuacionX = sPuntuacionDe + sNombreX + ": ";
        sPuntuacionO = sPuntuacionDe + sNombreO + ": ";

        buttons = List.of(b.b1, b.b2, b.b3, b.b4, b.b5, b.b6, b.b7, b.b8, b.b9);
        opciones = new String[]{"Salir del juego", "Jugar otra partida"};

        b.tvPuntuacionX.setText(sPuntuacionX + 0);
        b.tvPuntuacionO.setText(sPuntuacionO + 0);

        adBuilder = new AlertDialog.Builder(this);
        adBuilder.setCancelable(false);

        for (Button button : buttons)
            button.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Button bOnclik = ((Button) (view));

        if (turnoX) {
            bOnclik.setBackground(new ColorDrawable(getResources().getColor(R.color.black)));
            bOnclik.setText("X");
            turnoX = false;
        } else {
            bOnclik.setBackground(new ColorDrawable(getResources().getColor(R.color.black)));
            bOnclik.setText("O");
            turnoX = true;
        }
        bOnclik.setEnabled(false);
        calcularGanador();
    }

    private void calcularGanador() {

        // Condiciones para que gane el jugador X
        if (b.b1.getText().toString().equals("X") && b.b2.getText().toString().equals("X") && b.b3.getText().toString().equals("X") || b.b4.getText().toString().equals("X") && b.b5.getText().toString().equals("X") && b.b6.getText().toString().equals("X") || b.b7.getText().toString().equals("X") && b.b8.getText().toString().equals("X") && b.b9.getText().toString().equals("X") || b.b1.getText().toString().equals("X") && b.b4.getText().toString().equals("X") && b.b7.getText().toString().equals("X") || (b.b2.getText().toString().equals("X") && b.b5.getText().toString().equals("X") && b.b8.getText().toString().equals("X") || b.b3.getText().toString().equals("X") && b.b6.getText().toString().equals("X") && b.b9.getText().toString().equals("X") || b.b1.getText().toString().equals("X") && b.b5.getText().toString().equals("X") && b.b9.getText().toString().equals("X") || b.b3.getText().toString().equals("X") && b.b5.getText().toString().equals("X") && b.b7.getText().toString().equals("X"))) {
            sumarPuntuacion(b.tvPuntuacionX, sPuntuacionX, puntuacionX ++);
            menuOpciones();
        }

        // Condiciones para que gane el jugador O
        if (b.b1.getText().toString().equals("O") && b.b2.getText().toString().equals("O") && b.b3.getText().toString().equals("O") || b.b4.getText().toString().equals("O") && b.b5.getText().toString().equals("O") && b.b6.getText().toString().equals("O") || b.b7.getText().toString().equals("O") && b.b8.getText().toString().equals("O") && b.b9.getText().toString().equals("O") || b.b1.getText().toString().equals("O") && b.b4.getText().toString().equals("O") && b.b7.getText().toString().equals("O") || (b.b2.getText().toString().equals("O") && b.b5.getText().toString().equals("O") && b.b8.getText().toString().equals("O") || b.b3.getText().toString().equals("O") && b.b6.getText().toString().equals("O") && b.b9.getText().toString().equals("O") || b.b1.getText().toString().equals("O") && b.b5.getText().toString().equals("O") && b.b9.getText().toString().equals("O") || b.b3.getText().toString().equals("O") && b.b5.getText().toString().equals("O") && b.b7.getText().toString().equals("O"))) {
            sumarPuntuacion(b.tvPuntuacionO, sPuntuacionO, puntuacionO ++);
            menuOpciones();
        }

    }

    private void menuOpciones() {
        adBuilder.setTitle("Elige una opción");
        adBuilder.setItems(opciones, (dialog, opcion) -> {
            switch (opcion) {
                case 0:
                    finish();
                    break;

                case 1:
                    jugarOtra();
                    break;
            }
        });
        AlertDialog ad = adBuilder.create();
        ad.show();
    }


    private void jugarOtra() {
        b.tvPuntuacionX.setText(sPuntuacionX + puntuacionX);
        b.tvPuntuacionO.setText(sPuntuacionO + puntuacionO);
        for (Button button : buttons) {
            button.setText("");
            button.setEnabled(true);
            button.setBackground(new ColorDrawable(getResources().getColor(R.color.white)));
        }

    }



    private void sumarPuntuacion(TextView textView, String mensaje, int pJugador) {
        pJugador++;
        textView.setText(mensaje + pJugador);
        Toast.makeText(this, textView.getText().toString(), Toast.LENGTH_SHORT).show();
    }
}