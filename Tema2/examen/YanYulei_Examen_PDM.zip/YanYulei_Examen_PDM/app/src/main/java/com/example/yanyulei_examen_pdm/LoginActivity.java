package com.example.yanyulei_examen_pdm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.yanyulei_examen_pdm.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    ActivityLoginBinding b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        b = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
    }

    public void entrar(View view) {
        Intent intent = new Intent(this, JuegoActivity.class);
        intent.putExtra("nombreX", b.etNombreX.getText().toString());
        intent.putExtra("nombreO", b.etNombreO.getText().toString());
        startActivity(intent);
        finish();
    }

    public void salir(View view) {
        finish();
    }
}