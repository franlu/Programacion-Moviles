# JavierLama_Examen

## Tres en raya

### Introducción
- La aplicación esta diseñada de una forma sencilla, hay dos ventanas. La primera es un login en que se introduce el nombre de usuario y al pulsar el botón de la parte inferior se accede a la otra ventana, en esta ventana aparece el juego con un 3x3 de botones, en la parte superior de estos aparecerá el nombre del usuario y un mensaje con el turno.

### MainAcitity1
- El primer mainActivity lo he diseñado de esta forma porque un login debe ser sencillo para que no distraiga de lo que realmente es importante que es el juego.
### MainActivity2
- En el segundo mainActivity encontramos los 9 botones en la parte inferior que al ir pulsandolos se van coloreando con un circulo o una equis dependiendo del turno. En la parte superior izquierda hay un menú con dos opciones, un boton de ayuda en el que se crea un dialog que enseña las reglas, la siguiente opción del menú es una sorpresa que al pulsarla la redirecciona a mi perfil de github.
