package com.example.javierlama_examen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btnComenzar;
    TextView txtUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnComenzar = findViewById(R.id.btnComenzar);
        txtUsuario = findViewById(R.id.txtUsuario);
        btnComenzar.setOnClickListener((v) -> {
            Intent intent = new Intent (v.getContext(), MainActivity2.class);
            intent.putExtra("usuario", txtUsuario.getText().toString());
            startActivityForResult(intent, 0);
            finish();
        });
    }
}