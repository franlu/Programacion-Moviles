package com.example.javierlama_examen;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener{
    ImageButton btn1,btn2, btn3, btn4, btn5, btn6, btn7,btn8,btn9;
    TextView txtTurno,txtInsertUser,txtGanador;
    Boolean turno=true;
    AlertDialog.Builder dialog;
    ImageButton[] equis = new ImageButton[9];
    ImageButton[] circulos = new ImageButton[9];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        txtInsertUser = findViewById(R.id.txtInsertUser);
        txtTurno = findViewById(R.id.txtTurnos);
        txtTurno.setText("Turno del circulo");
        txtGanador = findViewById(R.id.txtGanador);


        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);

        Bundle bundle = getIntent().getExtras();
        String variableImportada=bundle.getString("usuario");
        txtInsertUser.setText(variableImportada);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu1, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
                dialog = new AlertDialog.Builder(MainActivity2.this);
                dialog.setTitle("Reglas:");
                dialog.setMessage("Gana el jugador que complete una fila horizontal o vertical del mismo tipo.");
                dialog.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo, int id) {
                        dialogo.cancel();
                    }
                });

                dialog.show();
                break;
            case R.id.item2:

                String url = "https://github.com/javilj03";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
        }
        return false;
    }


    @Override
    public void onClick(View view) {

        if(turno == true){
            turno = false;
            txtTurno.setText("Turno de la equis");
        }else{
            turno = true;
            txtTurno.setText("Turno del circulo");
        }
        switch(view.getId()){
            case R.id.btn1:
                    if(turno == true){
                        btn1.setImageResource(R.drawable.equis);
                        equis[0] = btn1;
                    }else{
                        btn1.setImageResource(R.drawable.circulo);
                        circulos[0] = btn1;
                    }
                    btn1.setEnabled(false);
                    comprobarLinea(0);
                break;
            case R.id.btn2:
                if(turno == true){
                    btn2.setImageResource(R.drawable.equis);
                    equis[1] = btn2;
                }else{
                    btn2.setImageResource(R.drawable.circulo);
                    circulos[1] = btn2;
                }
                btn2.setEnabled(false);
                comprobarLinea(1);
                break;
            case R.id.btn3:
                if(turno == true){
                    btn3.setImageResource(R.drawable.equis);
                    equis[2] = btn3;
                }else{
                    btn3.setImageResource(R.drawable.circulo);
                    circulos[2] = btn3;
                }
                btn3.setEnabled(false);
                comprobarLinea(2);
                break;
            case R.id.btn4:
                if(turno == true){
                    btn4.setImageResource(R.drawable.equis);
                    equis[3] = btn4;
                }else{
                    btn4.setImageResource(R.drawable.circulo);
                    circulos[3] = btn4;
                }
                btn4.setEnabled(false);
                comprobarLinea(3);
                break;
            case R.id.btn5:
                if(turno == true){
                    btn5.setImageResource(R.drawable.equis);
                    equis[4] = btn5;
                }else{
                    btn5.setImageResource(R.drawable.circulo);
                    circulos[4] = btn5;
                }
                btn5.setEnabled(false);
                comprobarLinea(4);
                break;
            case R.id.btn6:
                if(turno == true){
                    btn6.setImageResource(R.drawable.equis);
                    equis[5] = btn6;
                }else{
                    btn6.setImageResource(R.drawable.circulo);
                    circulos[5] = btn6;
                }
                btn6.setEnabled(false);
                comprobarLinea(5);
                break;
            case R.id.btn7:
                if(turno == true){
                    btn7.setImageResource(R.drawable.equis);
                    equis[6] = btn7;
                }else{
                    btn7.setImageResource(R.drawable.circulo);
                    circulos[6] = btn7;
                }
                btn7.setEnabled(false);
                comprobarLinea(6);
                break;
            case R.id.btn8:
                if(turno == true){
                    btn8.setImageResource(R.drawable.equis);
                    equis[7] = btn8;
                }else{
                    btn8.setImageResource(R.drawable.circulo);
                    circulos[7] = btn8;
                }
                btn8.setEnabled(false);
                comprobarLinea(7);
                break;
            case R.id.btn9:
                if(turno == true){
                    btn9.setImageResource(R.drawable.equis);
                    equis[8] = btn9;
                }else{
                    btn9.setImageResource(R.drawable.circulo);
                    circulos[8] = btn9;
                }
                btn9.setEnabled(false);
                comprobarLinea(8);
                break;
        }
    }

    public void comprobarLinea(int n) {
        if (n <= 2) {
            if (((equis[n] != null && equis[n + 3] != null && equis[n + 6] != null) ||
                    (circulos[n] != null && circulos[n + 3] != null && circulos[n + 6] != null))) {
                System.out.println("WIN");
                txtGanador.setText("Has ganado");
            }
        } else if (n <= 5) {
            if (((equis[n] != null && equis[n - 3] != null && equis[n + 3] != null) ||
                    (circulos[n] != null && circulos[n + 3] != null && circulos[n - 3] != null))) {
                System.out.println("WIN");
                txtGanador.setText("Has ganado");
            }
        } else if (n <= 8) {
            if (((equis[n] != null && equis[n - 3] != null && equis[n - 6] != null) ||
                    (circulos[n] != null && circulos[n - 3] != null && circulos[n - 6] != null))) {
                System.out.println("WIN");
                txtGanador.setText("Has ganado");
            }
        }
        if (n == 0 || n == 3 || n == 6) {
            if ((equis[n] != null && equis[n + 1] != null && equis[n + 2] != null)
                    || (circulos[n] != null && circulos[n + 1] != null && circulos[n + 2] != null)) {
                System.out.println("WIN");
                txtGanador.setText("Has ganado");
            }
        } else if (n == 1 || n == 4 || n == 7) {
            if ((equis[n] != null && equis[n + 1] != null && equis[n - 1] != null)
                    || (circulos[n] != null && circulos[n + 1] != null && circulos[n - 1] != null)) {
                System.out.println("WIN");
                txtGanador.setText("Has ganado");
            }
        } else if (n == 2 || n == 5 || n == 8) {
            if ((equis[n] != null && equis[n - 1] != null && equis[n - 2] != null)
                    || (circulos[n] != null && circulos[n - 1] != null && circulos[n - 2] != null)) {
                System.out.println("WIN");
                txtGanador.setText("Has ganado");
            }
        }


        }

    }