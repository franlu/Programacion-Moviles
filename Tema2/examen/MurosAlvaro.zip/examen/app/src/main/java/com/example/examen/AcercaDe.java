package com.example.examen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AcercaDe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acerca_de);
        Bundle datos = getIntent().getExtras();
        String recuperacion = datos.getString("variable");
        String recuperacion2 = datos.getString("variable2");
        TextView textView = findViewById(R.id.txtNom);
        textView.setText(" Bienvenidos "+recuperacion+" y "+recuperacion2+" ");

        Button btnintrucciones = findViewById(R.id.btnInstrucciones);
        btnintrucciones.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(view.getContext(), Instrucciones.class);
                intent2.putExtra("variable", recuperacion);
                intent2.putExtra("variable2", recuperacion2);
                startActivity(intent2);
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
}



