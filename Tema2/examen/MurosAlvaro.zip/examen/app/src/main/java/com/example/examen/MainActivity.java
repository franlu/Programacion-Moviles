package com.example.examen;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    AlertDialog.Builder dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText tj1 = findViewById(R.id.textName);
        EditText tj2 = findViewById(R.id.txtJ2);
        Button bentrar = findViewById(R.id.btnEntrar);
        bentrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String n = tj1.getText().toString();
                String n2 = tj2.getText().toString();

                if(tj1.getText().toString().length() == 0 || tj2.getText().toString().length() == 0 || tj1.getText().toString().length() == 0 && tj2.getText().toString().length() == 0 ){
                    dialog = new AlertDialog.Builder(MainActivity.this);
                    dialog.setTitle("Error");
                    dialog.setMessage("Introducir el nombre de los dos jugadores");
                    dialog.setPositiveButton("Continuar", (dialogo, id) ->{
                        dialogo.cancel();
                        if(tj1.getText().toString().length() == 0){
                            tj1.requestFocus();
                        }else{
                            tj2.requestFocus();
                        }


                    });
                    dialog.setNegativeButton("Salir de la APP", (dialogo, id) ->{
                        finish();
                    });
                    dialog.show();
                }else {
                    Intent intent = new Intent(view.getContext(), AcercaDe.class);
                    intent.putExtra("variable", n);
                    intent.putExtra("variable2", n2);
                    startActivity(intent);
                }
            }
        });

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
}






























