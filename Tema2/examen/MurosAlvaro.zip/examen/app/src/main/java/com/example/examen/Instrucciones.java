package com.example.examen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

public class Instrucciones extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instrucciones);
        Bundle datos = getIntent().getExtras();
        String recuperacion = datos.getString("variable");
        String recuperacion2 = datos.getString("variable2");
        TextView textView = findViewById(R.id.txtNo);
        textView.setText("  "+recuperacion+" y "+recuperacion2+" ");

        Button btnJugar = findViewById(R.id.btnJugar);
        CheckBox checkBox = findViewById(R.id.checkBox);
        btnJugar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkBox.isChecked()==true){
                    Intent intent3 = new Intent(view.getContext(), Jugar.class);
                    intent3.putExtra("variable", recuperacion);
                    intent3.putExtra("variable2", recuperacion2);
                    startActivity(intent3);
                }else{
                    Toast.makeText(Instrucciones.this, "Tiene que aceptar las condiciones para poder jugar", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
}