package com.example.examen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Jugar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jugar);

        Bundle datos = getIntent().getExtras();
        String recuperacion = datos.getString("variable");
        String recuperacion2 = datos.getString("variable2");
        TextView textView = findViewById(R.id.txtFinal);
        textView.setText(" "+recuperacion+" y "+recuperacion2+" ");

        EditText c1 = findViewById(R.id.a1);
        EditText c2 = findViewById(R.id.a2);
        EditText c3 = findViewById(R.id.a3);
        EditText c4 = findViewById(R.id.a4);
        EditText c5 = findViewById(R.id.a5);
        EditText c6 = findViewById(R.id.a6);
        EditText c7 = findViewById(R.id.a7);
        EditText c8 = findViewById(R.id.a8);
        EditText c9 = findViewById(R.id.a9);
        Button comprobar = findViewById(R.id.btnComprobar);
        TextView solucion = findViewById(R.id.SOLUCION);

        comprobar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a1 = c1.getText().toString();
                String a2 = c2.getText().toString();
                String a3 = c3.getText().toString();
                String a4 = c4.getText().toString();
                String a5 = c5.getText().toString();
                String a6 = c6.getText().toString();
                String a7 = c7.getText().toString();
                String a8 = c8.getText().toString();
                String a9 = c9.getText().toString();

                if(a1.equals("X")&&a2.equals("X")&&a3.equals("X")||a1.equals("X")&&a4.equals("X")&&a7.equals("X")||a3.equals("X")&&a6.equals("X")&&a9.equals("X")||a7.equals("X")&&a8.equals("X")&&a9.equals("X")||a1.equals("X")&&a5.equals("X")&&a9.equals("X") || a3.equals("X")&&a5.equals("X")&&a7.equals("X")){
                    solucion.setText(" has ganado jugador 1");

                }else if(a1.equals("0")&&a2.equals("0")&&a3.equals("0")||a1.equals("0")&&a4.equals("0")&&a7.equals("0")||a3.equals("0")&&a6.equals("0")&&a9.equals("0")||a7.equals("0")&&a8.equals("0")&&a9.equals("0")||a1.equals("0")&&a5.equals("X")&&a9.equals("0") || a3.equals("X")&&a5.equals("X")&&a7.equals("0")){
                    solucion.setText(" has perdido jugador 2");
                }else{

                }
            }
        });




    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
   /* public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.inicio:
                Intent intent = new Intent()
                break;
        }
        return false;
    }*/
}

