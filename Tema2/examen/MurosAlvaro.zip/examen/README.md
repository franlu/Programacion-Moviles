# EXAMEN
### MainActivity
Aqui se inserta los nombres de los dos jugadores y si alguno de ellos no esta insertado no se 
puede continuar.
### Acerca de Activity
Aqui sale informacion del juego y manda informacion de los nombres al siguiente activity.
### Instrucciones Activity
Aqui muestro las instrucciones del juego.
Incluyo un checkbox en el que tiene que ser clicada para poder continuar.
Una vez pulsado el boton este lleva al ultimo activity y pasa la informacion de los nombres.
### Juego Activity
Aqui tenemos el jeugo en funcionamiento
En el que lee todos los datos introducidos una vez pulsado el boton de comprobar y aqui se sale quien ha ganado.
