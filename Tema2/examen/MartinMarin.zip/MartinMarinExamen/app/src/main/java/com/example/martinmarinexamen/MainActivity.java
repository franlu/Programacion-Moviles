package com.example.martinmarinexamen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Context MainActivity = this;

    Button play;
    ImageButton topLeft;
    ImageButton topCenter;
    ImageButton topRight;
    ImageButton midLeft;
    ImageButton midCenter;
    ImageButton midRight;
    ImageButton botLeft;
    ImageButton botCenter;
    ImageButton botRight;
    ArrayList<ImageButton> butArray = new ArrayList<ImageButton>();

    TextView turnT;
    TextView cpuT;

    MenuItem howItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        turnT = findViewById(R.id.turnText);
        cpuT = findViewById(R.id.cpuInfo);
        turnT.setText("");
        cpuT.setText("");

        play = findViewById(R.id.playBut);
        play.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Random r = new Random();
                int turn = r.nextInt(2);

                play.setVisibility(View.INVISIBLE);

                topLeft.setImageResource(R.drawable.blank);
                topCenter.setImageResource(R.drawable.blank);
                topRight.setImageResource(R.drawable.blank);
                midLeft.setImageResource(R.drawable.blank);
                midCenter.setImageResource(R.drawable.blank);
                midRight.setImageResource(R.drawable.blank);
                botLeft.setImageResource(R.drawable.blank);
                botCenter.setImageResource(R.drawable.blank);
                botRight.setImageResource(R.drawable.blank);

                if(turn == 0){
                    playerTurn(1);
                    Toast.makeText(MainActivity, "The Player starts the game and plays with X.", Toast.LENGTH_LONG ).show();
                }
                else if(turn == 1){
                    Toast.makeText(MainActivity, "The CPU starts the game and plays with X.", Toast.LENGTH_LONG ).show();
                    cpuTurn(1);
                }
                else{
                    Toast.makeText(MainActivity, "An error has ocurred, try again.", Toast.LENGTH_LONG ).show();
                }
            }
        });

        topLeft = findViewById(R.id.topLeft);
        topCenter = findViewById(R.id.topCenter);
        topRight = findViewById(R.id.topRight);
        midLeft = findViewById(R.id.midLeft);
        midCenter = findViewById(R.id.midCenter);
        midRight = findViewById(R.id.midRight);
        botLeft = findViewById(R.id.botLeft);
        botCenter = findViewById(R.id.botCenter);
        botRight = findViewById(R.id.botRight);

        butArray.add(topLeft);
        butArray.add(topCenter);
        butArray.add(topRight);
        butArray.add(midLeft);
        butArray.add(midCenter);
        butArray.add(midRight);
        butArray.add(botLeft);
        butArray.add(botCenter);
        butArray.add(botRight);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.notItem:
                Toast.makeText(this, "", Toast.LENGTH_LONG ).show();
                return true;
            case R.id.howItem:
                Toast.makeText(this, "GLHF!", Toast.LENGTH_LONG ).show();
                return true;
            case R.id.abItem:
                Toast.makeText(this, "Thanks for playing!", Toast.LENGTH_LONG ).show();
                Intent howintent = new Intent (MainActivity, AboutActivity.class);
                startActivityForResult(howintent, 0);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void cpuTurn(int symbol){
        topLeft.setClickable(false);
        topCenter.setClickable(false);
        topRight.setClickable(false);
        midLeft.setClickable(false);
        midCenter.setClickable(false);
        midRight.setClickable(false);
        botLeft.setClickable(false);
        botCenter.setClickable(false);
        botRight.setClickable(false);
        turnT.setText("It's the turn of the CPU");

        Random r = new Random();
        int flip = r.nextInt(10);

        if(symbol == 1){
            butArray.get(flip).setImageResource(R.drawable.x);
        }
        else{
            butArray.get(flip).setImageResource(R.drawable.o);
        }

        playerTurn(-1);
    }

    public void playerTurn(int symbol){
        topLeft.setClickable(true);
        topCenter.setClickable(true);
        topRight.setClickable(true);
        midLeft.setClickable(true);
        midCenter.setClickable(true);
        midRight.setClickable(true);
        botLeft.setClickable(true);
        botCenter.setClickable(true);
        botRight.setClickable(true);




    }
}