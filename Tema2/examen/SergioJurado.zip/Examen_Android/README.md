Voy a realizar el juego que todo el mundo conoce: El tres en ralla.
Para realizar este juego he utilizado varias ventanas, las cuales vas pasando de una a otra a través de los botones con la funcion OnCLickListener y con los Intents.
