package com.example.examen_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    Button Jugar;
    Button Reglas;
    TextView Usuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Usuario = findViewById(R.id.txt_Usuario);
        Jugar = findViewById(R.id.btn_jugar);
        Reglas = findViewById(R.id.btn_reglas);

        Reglas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), MainActivity3.class);
                startActivityForResult(intent, 0);
            }
        });

        Jugar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), MainActivity4.class);
                startActivityForResult(intent, 0);
            }
        });
    }

}