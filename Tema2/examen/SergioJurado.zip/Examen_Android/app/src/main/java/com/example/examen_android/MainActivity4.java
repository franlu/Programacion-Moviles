package com.example.examen_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;


public class MainActivity4 extends AppCompatActivity {
    ImageView p1 = findViewById(R.id.posicion1);
    ImageView p2 = findViewById(R.id.posicion2);
    ImageView p3 = findViewById(R.id.posicion3);
    ImageView p4 = findViewById(R.id.posicion4);
    ImageView p5 = findViewById(R.id.posicion5);
    ImageView p6 = findViewById(R.id.posicion6);
    ImageView p7 = findViewById(R.id.posicion7);
    ImageView p8 = findViewById(R.id.posicion8);
    ImageView p9 = findViewById(R.id.posicion9);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
    }
}

