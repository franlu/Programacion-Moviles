package dam.cazorla.ejemplo1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    //La creo aquí porque voy a usarla en distintos métodos
    String variable_importada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        /*Para tomar datos desde otros activities se usa la variable tipo Bundle*/
        Bundle bundle = getIntent().getExtras();
        variable_importada=bundle.getString("frase");

        TextView mitexto = (TextView) findViewById(R.id.textoNombre);
        mitexto.setText("La variable importada es..."+variable_importada);

        Button boton3 = (Button) findViewById(R.id.botonVolver);
        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent (v.getContext(), MainActivity.class);
                startActivityForResult(intent2, 0);
            }
        });

        Log.d("Verbose","ESTADO 2. onCreate()");
    }

    /*A partir de aquí están TODAS las funciones que se disparan EN ORDEN cuando se cambia de estado en la APP
    Los más importantes son los vistos en teoría (onCreate, onPause, onStart..) , aunque en casos más específicos se podría utilizar cualquiera de los otros */

    @Override
    public void onStart() {
        super.onStart();
        Log.d("Verbose","ESTADO 3. onStart()");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("Verbose","ESTADO 14. onPause()");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d("Verbose","ESTADO 15. onStop()");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("Verbose","ESTADO 16. onDestroy()");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("Verbose","ESTADO 7. onResume()");
    }
    /*
    @Override
    public void onContentChanged() {
        super.onContentChanged();
        Log.d("Verbose","ESTADO 1. onContentChanged()");
    }


    @Override
    public void onRestoreInstanceState(Bundle restoreInstanceState) {
        Log.d("Verbose","ESTADO 4. onRestoreinstaneState()");
        super.onRestoreInstanceState(restoreInstanceState);
    }

    @Override
    public void onRestart() {
        super.onRestart();
        Log.d("Verbose","ESTADO 5. onRestart()");
    }

    @Override
    protected void onPostCreate(Bundle onpostcrete) {
        super.onPostCreate(onpostcrete);
        Log.d("Verbose","ESTADO 6. onPostCreate()");
    }


    @Override
    protected void onPostResume() {
        super.onPostResume();
        Log.d("Verbose","ESTADO 8. onPostResume()");
    }

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Log.d("Verbose","ESTADO 9. onAttachedToWindow()");
    }

    @Override
    public void onWindowFocusChanged(boolean bo) {
        super.onWindowFocusChanged(true);
        Log.d("Verbose","ESTADO 10. onWindowFocusChanged()");
    }

    @Override
    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        Log.d("Verbose","ESTADO 11. onUserLeaveHint()");
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        int ii = 0;
        Log.d("Verbose","ESTADO 12. onUserInteraction()");
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        Log.d("Verbose","ESTADO 13. onSaveInstanceState()");
    }


    @Override
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Log.d("Verbose","ESTADO 17. onDetachedFromWindow()");
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.d("Verbose","ESTADO 18. onConfigurationChanged()");
    }

    @Override
    public boolean onSearchRequested() {
        super.onSearchRequested();
        Log.d("Verbose","ESTADO 19. onSearchRequested()");
        return false;
    }


     */

    //Intent implícito: es algo que mi app no puede hacer y quiero que el SSOO haga por mi:
    //Llamar por teléfono, poner una alarma, reproducir música, abrir una URL, añadir un contacto...

    //Intent Llamar por teléfono
    public void llama_intent_implicito_llamada(View view) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("tel:666777888")));

    }

    //Intent Añadir Contacto
    public void llama_intent_implicito_contacto(View view) {
        Intent intent = new Intent(Intent.ACTION_INSERT);
        intent.setType(ContactsContract.Contacts.CONTENT_TYPE);
        intent.putExtra(ContactsContract.Intents.Insert.NAME, variable_importada);
        //También se podria incluir teléfono y el email
        //intent.putExtra(ContactsContract.Intents.Insert.PHONE, "666777888");
        //intent.putExtra(ContactsContract.Intents.Insert.EMAIL, "alumno@dam.es");

        startActivity(intent);

    }
}

