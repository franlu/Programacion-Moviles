package dam.cazorla.area_circulo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    //Se declaran las variables de referencia
    EditText radio;
    Button circulo;
    TextView resultado;

    //Este elemento es el dialog, para mostrar mensajes
    AlertDialog.Builder dialog;

    //Variables para formatear el resultado
    double area;
    DecimalFormat formato = new DecimalFormat("#.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Como siempre, se enlazan los views con las variables internas
        radio = (EditText) findViewById(R.id.textoRadio);
        circulo = (Button) findViewById(R.id.botonCirculo);
        resultado = (TextView) findViewById(R.id.textoResultado);
        circulo.setText("Calcular");


        circulo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Aquí se juega con el nombre del botón, si es "limpiar" es porque ya hemos calculado correctamente
                if(circulo.getText().toString().equals("Limpiar")){
                    radio.setText("");
                    resultado.setText("");
                    radio.requestFocus();
                    circulo.setText("Calcular");
                }else{//Aquí se controla el error de darle al botón si no se ha metido nada en la caja
                    if(radio.getText().toString().length() == 0){
                        //se crea el dialog pasándole el contexto (donde estamos)
                        dialog = new AlertDialog.Builder(MainActivity.this);
                        dialog.setTitle("Error");
                        dialog.setMessage("Introducir el radio del círculo");
                        //PositiveButton se refiere al botón más a la derecha, negative más a la izquierda, y neutral a la izquierda del todo
                        // NEUTRAL       NEGATIVE POSITIVE
                        dialog.setPositiveButton("CONTINUAR", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogo, int id) {
                                dialogo.cancel();//No es necesaria para cerrarlo, pero si programamos un onCancelListener ejecutará lo que hay ahí dentro
                                radio.requestFocus();
                            }
                        });
                        dialog.setNegativeButton("SALIR DE APP", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogo, int id) {
                                finish();//Cierra el Activity, y lo deja en segundo plano, si lo hubiera llamado otro activity volvería al anterior
                                          }
                        });
                        dialog.show();//Muestra el Dialog
                    }else{
                        area = Math.pow(Double.parseDouble(radio.getText().toString()), 2.0) * Math.PI;
                        resultado.setText("El área es calculada es: " + formato.format(area));
                        circulo.setText("Limpiar");
                    }
                }
            }
        });

    }
}
