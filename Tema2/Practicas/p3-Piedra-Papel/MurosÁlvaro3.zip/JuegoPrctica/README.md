# JuegoPractica
# He usado una primera vista para el jugador1.
