package com.example.juegoprctica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SolucionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solucion);

        Bundle datos = getIntent().getExtras();
        String recuperacion = datos.getString("variable");
        TextView textView = findViewById(R.id.txtSolucion);
        textView.setText(" "+recuperacion+" ");

        Button btnVolver = findViewById(R.id.btnIniciar);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}