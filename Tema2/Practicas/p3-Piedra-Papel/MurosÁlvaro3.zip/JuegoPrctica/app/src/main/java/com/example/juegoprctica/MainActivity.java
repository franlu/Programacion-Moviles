package com.example.juegoprctica;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    AlertDialog.Builder dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText opcionJugador = findViewById(R.id.jugador1);
        Button btnJ1 = findViewById(R.id.btnJugar);
        btnJ1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String jugador2[] ={"Piedra", "Papel", "Tijera", "Lagarto", "Spock"};
                Random r = new Random();
                int aleatorio = r.nextInt(5);
                String jugador1 = opcionJugador.getText().toString();

                if(opcionJugador.getText().toString().length() == 0){
                    dialog = new AlertDialog.Builder(MainActivity.this);
                    dialog.setTitle("Error");
                    dialog.setMessage("Introducir la opción del jugador");
                    dialog.setPositiveButton("Continuar", (dialogo, id) ->{
                        dialogo.cancel();
                        opcionJugador.requestFocus();
                    });
                    dialog.setNegativeButton("Salir de la APP", (dialogo, id) ->{
                       finish();
                    });
                    dialog.show();
                }else{

                    if(jugador1.equals(aleatorio)){
                        System.out.println("hola");
                        Intent intent = new Intent(view.getContext(), SolucionActivity.class);
                        String empate = "EMPATE";
                        intent.putExtra("variable", empate);
                        startActivity(intent);

                    }else if(jugador1.equals("Piedra")&&(aleatorio==3  || aleatorio==2) || jugador1.equals("Papel")&&(aleatorio==0||aleatorio==4)||jugador1.equals("Tijera")&&(aleatorio==1||aleatorio==3) || jugador1.equals("Lagarto")&&(aleatorio==4||aleatorio==1) || jugador1.equals("Spock")&&(aleatorio==2||aleatorio==0)){
                        System.out.println("hola");
                        Intent intent2 = new Intent(view.getContext(), SolucionActivity.class);
                        String ganado = "ERES EL GANADOR";
                        intent2.putExtra("variable", ganado);
                        startActivity(intent2);

                    }else if(jugador1.equals("Piedra")&&(aleatorio==1||aleatorio==4) || jugador1.equals("Papel")&&(aleatorio==2||aleatorio==3) || jugador1.equals("Tijera")&&(aleatorio==0||aleatorio==4) || jugador1.equals("Lagarto")&&(aleatorio==0||aleatorio==2) || jugador1.equals("Spock")&&(aleatorio==1||aleatorio==3)){
                        System.out.println("hola");
                        Intent intent3 = new Intent(view.getContext(), SolucionActivity.class);
                        String derrota = "ERES EL PERDEDOR";
                        intent3.putExtra("variable", derrota);
                        startActivity(intent3);

                    }else{
                        System.out.println("h");
                    }
                }

            }
        });
    }
}