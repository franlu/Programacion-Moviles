package com.example.piedrapapeltijeras;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btn_Iniciar;
    EditText et_NombreUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_Iniciar = findViewById(R.id.btnIniciarJuego);
        et_NombreUser = findViewById(R.id.editTextNombre);

        btn_Iniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (et_NombreUser.getText().toString().equals("")){
                    Toast.makeText(MainActivity.this, "No has insertado ningun nombre", Toast.LENGTH_SHORT).show();
                }else{
                    Intent intent = new Intent (view.getContext(), JuegoActivity.class);
                    intent.putExtra("usuario", et_NombreUser.getText().toString());
                    startActivityForResult(intent, 0);
                }
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mItem1:
                Toast.makeText(this, "Creador: Jose Antonio Orellana Gomez", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}