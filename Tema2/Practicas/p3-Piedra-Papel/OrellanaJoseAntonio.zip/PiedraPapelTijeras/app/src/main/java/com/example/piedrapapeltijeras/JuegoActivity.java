package com.example.piedrapapeltijeras;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class JuegoActivity extends AppCompatActivity {
    TextView txtJugador;
    TextView txtpuntuacion;
    ImageView imgViewRival;
    ImageView imgViewMia;
    Random r = new Random();
    AlertDialog.Builder dialog;
    int nAleatorio = 0;
    int puntajeMio = 0;
    int puntajeRival = 0;
    Button btnSacoPapel, btnSacoTijeras, btnSacoPiedra, btnSacoSpock, btnSacoLagarto;
    int imgCosas [] = new int[]{R.drawable.lagarto, //0
            R.drawable.spock, //1
            R.drawable.papel, //2
            R.drawable.tijeras, //3
            R.drawable.piedra, //4
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);

        imgViewMia = findViewById(R.id.imageViewYo);
        imgViewRival = findViewById(R.id.imageViewRival);
        btnSacoPapel = findViewById(R.id.btnPapel);
        btnSacoLagarto = findViewById(R.id.btnLagarto);
        btnSacoPiedra = findViewById(R.id.btnPiedra);
        btnSacoSpock = findViewById(R.id.btnSpock);
        btnSacoTijeras = findViewById(R.id.btnTijeras);

        txtJugador = findViewById(R.id.textViewJugador);
        txtpuntuacion = findViewById(R.id.textViewPuntuacion);

        Bundle bundle = getIntent().getExtras();
        String usuario = bundle.getString("usuario");
        txtJugador.setText("Jugador: "+usuario);

        puntajeMio = 0;
        puntajeRival = 0;

        btnSacoPapel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgViewMia.setImageResource(imgCosas[2]);
                nAleatorio = r.nextInt(5);
                imgViewRival.setImageResource(imgCosas[nAleatorio]);

                if (2 == nAleatorio){
                    Toast.makeText(JuegoActivity.this, "Empate", Toast.LENGTH_SHORT).show();

                }else if (1 == nAleatorio || 3 == nAleatorio){
                    Toast.makeText(JuegoActivity.this, "Ganaste", Toast.LENGTH_SHORT).show();
                    puntajeMio++;

                }else{
                    Toast.makeText(JuegoActivity.this, "Perdiste", Toast.LENGTH_SHORT).show();
                    puntajeRival++;
                }
                txtpuntuacion.setText(puntajeMio+"-"+puntajeRival);
            }
        });

        btnSacoTijeras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgViewMia.setImageResource(imgCosas[3]);
                nAleatorio = r.nextInt(5);
                imgViewRival.setImageResource(imgCosas[nAleatorio]);

                if (3 == nAleatorio){
                    Toast.makeText(JuegoActivity.this, "Empate", Toast.LENGTH_SHORT).show();

                }else if (0 == nAleatorio || 2 == nAleatorio){
                    Toast.makeText(JuegoActivity.this, "Ganaste", Toast.LENGTH_SHORT).show();
                    puntajeMio++;

                }else{
                    Toast.makeText(JuegoActivity.this, "Perdiste", Toast.LENGTH_SHORT).show();
                    puntajeRival++;
                }
                txtpuntuacion.setText(puntajeMio+"-"+puntajeRival);
            }
        });

        btnSacoSpock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgViewMia.setImageResource(imgCosas[1]);
                nAleatorio = r.nextInt(5);
                imgViewRival.setImageResource(imgCosas[nAleatorio]);

                if (1 == nAleatorio){
                    Toast.makeText(JuegoActivity.this, "Empate", Toast.LENGTH_SHORT).show();

                }else if (4 == nAleatorio || 3 == nAleatorio){
                    Toast.makeText(JuegoActivity.this, "Ganaste", Toast.LENGTH_SHORT).show();
                    puntajeMio++;

                }else{
                    Toast.makeText(JuegoActivity.this, "Perdiste", Toast.LENGTH_SHORT).show();
                    puntajeRival++;
                }
                txtpuntuacion.setText(puntajeMio+"-"+puntajeRival);
            }
        });

        btnSacoLagarto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgViewMia.setImageResource(imgCosas[0]);
                nAleatorio = r.nextInt(5);
                imgViewRival.setImageResource(imgCosas[nAleatorio]);

                if (0 == nAleatorio){
                    Toast.makeText(JuegoActivity.this, "Empate", Toast.LENGTH_SHORT).show();

                }else if (1 == nAleatorio || 2 == nAleatorio){
                    Toast.makeText(JuegoActivity.this, "Ganaste", Toast.LENGTH_SHORT).show();
                    puntajeMio++;

                }else{
                    Toast.makeText(JuegoActivity.this, "Perdiste", Toast.LENGTH_SHORT).show();
                    puntajeRival++;
                }
                txtpuntuacion.setText(puntajeMio+"-"+puntajeRival);
            }
        });

        btnSacoPiedra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgViewMia.setImageResource(imgCosas[4]);
                nAleatorio = r.nextInt(5);
                imgViewRival.setImageResource(imgCosas[nAleatorio]);

                if (4 == nAleatorio){
                    Toast.makeText(JuegoActivity.this, "Empate", Toast.LENGTH_SHORT).show();

                }else if (0 == nAleatorio || 3 == nAleatorio){
                    Toast.makeText(JuegoActivity.this, "Ganaste", Toast.LENGTH_SHORT).show();
                    puntajeMio++;

                }else{
                    Toast.makeText(JuegoActivity.this, "Perdiste", Toast.LENGTH_SHORT).show();
                    puntajeRival++;
                }
                txtpuntuacion.setText(puntajeMio+"-"+puntajeRival);
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menujuego, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mItem1:
                Toast.makeText(this, "Creador: Jose Antonio Orellana Gomez", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.mItem2:
                dialog = new AlertDialog.Builder(JuegoActivity.this);
                dialog.setTitle("Confirmacion");
                dialog.setMessage("¿Seguro que deseas cerrar sesion?");
                dialog.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo, int id) {
                        dialogo.cancel();
                        imgViewMia.requestFocus();
                    }
                });
                dialog.setNegativeButton("Cerrar sesion", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo, int id) {
                        finish();
                    }
                });
                dialog.show();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}