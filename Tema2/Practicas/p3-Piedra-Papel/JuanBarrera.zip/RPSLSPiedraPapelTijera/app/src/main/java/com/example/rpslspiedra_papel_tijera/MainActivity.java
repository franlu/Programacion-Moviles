package com.example.rpslspiedra_papel_tijera;
/**
 * @author Juan Barrera Cuesta
 */

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    TextView nombres, puntIA,puntJuga;
    ImageView opJugador, opIA;
    int[] opciones = {R.drawable.rock,R.drawable.paper,R.drawable.scissors,
            R.drawable.lizard,R.drawable.spock};
    ImageButton[] botones = new ImageButton[5];
    int puntosIa = 0, puntosJugador = 0;

    AlertDialog.Builder dialog;
    View ay = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bundle bundle = getIntent().getExtras();
        String variable = bundle.getString("nickname");

        opJugador = findViewById(R.id.imgViewJugador);
        opIA = findViewById(R.id.imgViewIA);
        botones[0] = findViewById(R.id.imgBtnRock);
        botones[1] = findViewById(R.id.imgBtnPaper);
        botones[2] = findViewById(R.id.imgBtnScissors);
        botones[3] = findViewById(R.id.imgBtnLizzard);
        botones[4] = findViewById(R.id.imgBtnSpock);
        nombres = findViewById(R.id.txtStats);
        nombres.setText(variable);
        puntIA = findViewById(R.id.txtContIA);
        puntJuga = findViewById(R.id.txtContJuga);

        botones[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                duelo(0, view);
            }
        });

        botones[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                duelo(1, view);
            }
        });

        botones[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                duelo(2, view);
            }
        });

        botones[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                duelo(3, view);
            }
        });

        botones[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                duelo(4, view);
            }
        });
    }
    //MENÚ
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.itmAcerca) {
            Toast.makeText(this, "Programa creado por: Juan Barrera", Toast.LENGTH_LONG).show();
            return true;
        }else if(item.getItemId() == R.id.itmAyuda){
            Intent intent = new Intent(this, HelpActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void duelo(int i, View v){
        int eleccion = new Random().nextInt(5);
        opJugador.setVisibility(View.VISIBLE);
        opJugador.setImageResource(opciones[i]);

        opIA.setVisibility(View.VISIBLE);
        opIA.setImageResource(opciones[eleccion]);

        switch (i){
            case 0://Caso jugador saca piedra
                if(eleccion == 3 || eleccion == 2){ //Si la IA saca lagarto o tijeras
                    puntosJugador+=1;
                    puntJuga.setText(""+puntosJugador);
                }else if(eleccion == 1 || eleccion == 4){ //Si la IA saca papel o Spock
                    puntosIa+=1;
                    puntIA.setText(""+puntosIa);
                }
                comprobarPunt(v);
                ocultar();
                break;
            case 1://Caso jugador saca papel
                if(eleccion == 4 || eleccion == 0){ //Si la IA saca spock o piedra
                    puntosJugador+=1;
                    puntJuga.setText(""+puntosJugador);
                }else if(eleccion == 2 || eleccion == 3){ //Si la IA saca tijeras o lagarto
                    puntosIa+=1;
                    puntIA.setText(""+puntosIa);
                }
                comprobarPunt(v);
                ocultar();
                break;
            case 2://Caso jugador saca tijeras
                if(eleccion == 1 || eleccion == 3){ //Si la IA saca papel o lagarto
                    puntosJugador+=1;
                    puntJuga.setText(""+puntosJugador);
                }else if(eleccion == 0 || eleccion == 4){ //Si la IA saca piedra o Spock
                    puntosIa+=1;
                    puntIA.setText(""+puntosIa);
                }
                comprobarPunt(v);
                ocultar();
                break;
            case 3://Caso jugador saca lagarto
                if(eleccion == 4 || eleccion == 1){ //Si la IA saca Spock o papel
                    puntosJugador+=1;
                    puntJuga.setText(""+puntosJugador);
                }else if(eleccion == 0 || eleccion == 2){ //Si la IA saca piedra o tijeras
                    puntosIa+=1;
                    puntIA.setText(""+puntosIa);
                }
                comprobarPunt(v);
                ocultar();
                break;
            case 4://Caso jugador saca Spock
                if(eleccion == 0 || eleccion == 2){ //Si la IA saca piedra o tijeras
                    puntosJugador+=1;
                    puntJuga.setText(""+puntosJugador);
                }else if(eleccion == 1 || eleccion == 3){ //Si la IA saca papel o lagarto
                    puntosIa+=1;
                    puntIA.setText(""+puntosIa);
                }
                comprobarPunt(v);
                ocultar();
                break;
            default:
                Toast.makeText(this, "No gana nadie", Toast.LENGTH_SHORT).show();
                ocultar();
                break;
        }
    }

    private void ocultar(){
        Handler handler = new Handler();
        handler.postDelayed(() -> {
            opJugador.setVisibility(View.INVISIBLE);
            opIA.setVisibility(View.INVISIBLE);
        },(700));
    }

    private void reiniciar(){
        puntIA.setText("0");
        puntJuga.setText("0");
        puntosIa = 0;
        puntosJugador = 0;
        ocultar();
    }

    private void comprobarPunt(View v){
        String recoPuntIA = puntIA.getText().toString();
        String recoPuntJug = puntJuga.getText().toString();

        if(recoPuntJug.equals("3")){
            dialog = new AlertDialog.Builder(MainActivity.this);
            dialog.setTitle("Ganador");
            dialog.setMessage("El jugador: "+nombres.getText().toString()+" ha ganado.");

            dialog.setPositiveButton("ACEPTAR", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent(v.getContext(), WelcomeActivity.class);
                    startActivity(intent);
                    finish();
                }
            });
            dialog.setNegativeButton("REINICIAR", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo, int id) {
                    reiniciar();
                }
            });
            dialog.show();
        }else if(recoPuntIA.equals("3")){
            dialog = new AlertDialog.Builder(MainActivity.this);
            dialog.setTitle("Ganador");
            dialog.setMessage("La IA ha ganado.");

            dialog.setPositiveButton("ACEPTAR", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent(v.getContext(), WelcomeActivity.class);
                    startActivity(intent);
                    finish();
                }
            });
            dialog.setNegativeButton("REINICIAR", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo, int id) {
                    reiniciar();
                }
            });
            dialog.show();
        }
    }
}