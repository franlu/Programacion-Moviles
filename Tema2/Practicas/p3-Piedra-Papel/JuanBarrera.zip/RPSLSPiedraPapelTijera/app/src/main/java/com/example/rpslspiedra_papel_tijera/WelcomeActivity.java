package com.example.rpslspiedra_papel_tijera;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class WelcomeActivity extends AppCompatActivity {

    EditText nick;
    Button jugar;
    AlertDialog.Builder dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        nick = findViewById(R.id.editTextNickname);
        jugar = findViewById(R.id.btnComenzar);

        jugar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nickString = nick.getText().toString();

                if(nickString.equals("") || nickString.length()>7){
                    dialog = new AlertDialog.Builder(WelcomeActivity.this);
                    dialog.setTitle("Error de nickname");
                    dialog.setMessage("El nickname introducido no es válido\n" +
                            "Caractéres mínimos: 1 // Caractéres máximos: 7");

                    dialog.setPositiveButton("ACEPTAR", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                            nick.requestFocus();
                        }
                    });
                    dialog.show();
                }else{
                    Intent intent = new Intent(view.getContext(), MainActivity.class);
                    intent.putExtra("nickname",nickString);
                    startActivityForResult(intent,0);
                    finish();
                }
            }
        });
    }
}