# Juego Piedra-Papel-Tijeras-Lagarto-Spock

Juego realizado por Juan Barrera Cuesta 2ºDAM

---------------------
# Diseño principal

Para esta ocasión usaremos dos Activities, una principal donde se pedirá al usuario su nickname para jugar y un segundo activity donde se realizará el juego en s
