package com.example.spockgame;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.TaskStackBuilder;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    String[] values = {
            "Piedra",
            "Papel",
            "Tijeras",
            "Lagarto",
            "Spock"
    };
    int notifID=1;
    AlertDialog.Builder dialog;

    Button[] btns = new Button[5];
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Bundle b = getIntent().getExtras();
        String user = b.getString("user");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnRock = findViewById(R.id.btnRock);
        TextView outputIA = findViewById(R.id.txtIAOutput);
        TextView userPlaying = findViewById(R.id.txtUserPlaying);
        userPlaying.setText("Usuario: " + user);

        btns[0] = findViewById(R.id.btnRock);
        btns[1] = findViewById(R.id.btnPaper);
        btns[2] = findViewById(R.id.btnSciz);
        btns[3] = findViewById(R.id.btnLizard);
        btns[4] = findViewById(R.id.btnSpock);



        Arrays.stream(btns).parallel().forEach(btn -> btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String valueClicked = btn.getText().toString();
                String valueIA = valueIA();
                outputIA.setText(valueIA);
                checkWin(valueClicked, valueIA, view);
            }
        }));
    }

    public String valueIA(){
        int r = new Random().nextInt(5);
        return values[r];
    }

    public void checkWin(String userValue, String iaValue, View v) {
        /*
         * rock  : W-> sci, liz // L-> pap, spo
         * pap   : W-> roc, spo // L-> sci, liz
         * sci   : W-> pap, liz // L-> roc, spo
         * liz   : W-> pap, spo // L-> roc, sci
         * spo   : W-> roc, sci // L-> pap, liz
         * */
        switch (userValue) {
            case "Piedra":
                if (iaValue.equals("Tijeras") || iaValue.equals("Lagarto")) {
                    Toast.makeText(this, "Ganaste", Toast.LENGTH_SHORT).show();
                } else if (iaValue.equals("Papel") || iaValue.equals("Spock")) {
                    Toast.makeText(this, "Perdiste", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Empataste", Toast.LENGTH_SHORT).show();
                    LanzarNotificación(v);
                }
                break;
            case "Papel":
                if (iaValue.equals("Piedra") || iaValue.equals("Spock")) {
                    Toast.makeText(this, "Ganaste", Toast.LENGTH_SHORT).show();
                } else if (iaValue.equals("Lagarto") || iaValue.equals("Tijeras")) {
                    Toast.makeText(this, "Perdiste", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Empataste", Toast.LENGTH_SHORT).show();
                    LanzarNotificación(v);
                }
                break;
            case "Tijeras":
                if (iaValue.equals("Papel") || iaValue.equals("Lagarto")) {
                    Toast.makeText(this, "Ganaste", Toast.LENGTH_SHORT).show();
                } else if (iaValue.equals("Piedra") || iaValue.equals("Spock")) {
                    Toast.makeText(this, "Perdiste", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Empataste", Toast.LENGTH_SHORT).show();
                    LanzarNotificación(v);
                }
                break;
            case "Lagarto":
                if (iaValue.equals("Papel") || iaValue.equals("Spock")) {
                    Toast.makeText(this, "Ganaste", Toast.LENGTH_SHORT).show();
                } else if (iaValue.equals("Piedra") || iaValue.equals("Tijeras")) {
                    Toast.makeText(this, "Perdiste", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Empataste", Toast.LENGTH_SHORT).show();
                    LanzarNotificación(v);
                }
                break;
            case "Spock":
                if (iaValue.equals("Tijeras") || iaValue.equals("Piedra")) {
                    Toast.makeText(this, "Ganaste", Toast.LENGTH_SHORT).show();
                } else if (iaValue.equals("Papel") || iaValue.equals("Lagarto")) {
                    Toast.makeText(this, "Perdiste", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Empataste", Toast.LENGTH_SHORT).show();
                    LanzarNotificación(v);
                }
                break;
            default:
                Toast.makeText(this, "Strange Error", Toast.LENGTH_SHORT).show();
                break;

        }
        ThrowDialog();
    }
    public void LanzarNotificación(View v) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "NotityChannel")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("SpockGame")
                .setContentText("¿Empataste? ¡Eso si que es casualidad!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        Intent resultadoIntent = new Intent(this, MainActivity.class);

        TaskStackBuilder pila = TaskStackBuilder.create(this);
        pila.addParentStack(MainActivity.class);


        pila.addNextIntent(resultadoIntent);
        PendingIntent resultadoPendingIntent =
                pila.getPendingIntent(0,PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(resultadoPendingIntent);


        NotificationManager notificador = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel canal = new NotificationChannel(
                    "NotityChannel",
                    "Canal de Notificaciones para SpockGame",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            notificador.createNotificationChannel(canal);
        }
        notificador.notify(notifID, builder.build());
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    };

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()) {
            case R.id.item1:
                Toast.makeText(this, "Aplicacion hecha por Javier Garcia", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item2:
                finish();
                return true;
            default:
                return true;
        }
    }
    public void ThrowDialog(){
        dialog = new AlertDialog.Builder(MainActivity.this);
        dialog.setTitle("Has Terminado");
        dialog.setMessage("¿Quieres seguir jugando?");

        dialog.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo, int id) {
                dialogo.cancel();
            }
        });
        dialog.setNegativeButton("No, Salir", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo, int id) {
                finish();
            }
        });
        dialog.show();
    }
}