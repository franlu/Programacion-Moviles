package com.example.spockgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    String validUser = "usuario";
    String validPass = "usuario";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //Button
        Button login = findViewById(R.id.btnLogin);
        //Inputs
        EditText user = findViewById(R.id.txtInputUser);
        EditText pass = findViewById(R.id.txtInputPass);

        Button btnLogin = findViewById(R.id.btnLogin);

        //On Click
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String inputUser;
                String inputPass;

                inputUser = user.getText().toString();
                inputPass = pass.getText().toString();

                boolean isValid = loginChecker(inputUser, inputPass);

                if (isValid){
                    Intent valid = new Intent(view.getContext(), MainActivity.class).putExtra("user", inputUser);
                    startActivityForResult(valid, 0);
                }else{
                    Intent notValid = new Intent(view.getContext(), LoginFailedActivity.class);
                    startActivity(notValid);
                }
            }
        });
    }

    public boolean loginChecker(String user, String pass){
        if(user.equals(validUser) && pass.equals(validPass)){
            return true;
        }else {
            return false;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    };

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()) {
            case R.id.item1:
                Toast.makeText(this, "Aplicacion hecha por Javier Garcia", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item2:
                finish();
                return true;
            default:
                return true;
        }
    }
}