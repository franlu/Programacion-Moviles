# SpockGame
### Hecho por Javier Garcia
 
La aplicacion consta del juego Piedra, Papel, Tijera, Lagarto, Spock, el famoso juego de la serie The Big Bang Theory, en la cual Sheldon Cooper juega junto a sus amigos.

Jugaremos contra la IA. Para ello, he diseñado un pequeño metodo el cual, junto a una lista de Strings saca valores al azar.
```
valueIA()
```

He decidido usar un boton para cada posible opcion (5) y un pequeño cuadro de texto en el cual nos indica cual ha sido la elección de la IA 

Para la funcionabilidad del juego, he preparado una funcion que compara ambos valores y dependiendo de cual sean, saca el resultado.
```
checkWin()
```

Para el juego, he decidido que es buena idea crear un pequeño login donde, pasandole unas credenciales previamente diseñadas, accedes al juego o no. Para ello, he creado 2 nuevas actividades, una para el login y otra para cuando las credenciales no son válidas
```
loginChecker()
```

Junto al login he añadido una imagen como "firma" de proyecto con mi logo para rellenar mas el login

He añadido que la aplicacion lance una notificacion cuando tanto la IA como el jugador sacan el mismo valor, ya que solo hay un 10%(20% por cada jugador) de que ambos saquen el mismo valor

```
LanzarNotificacion(View v)
```

He añadido un Dialog despues de cada partida por si no quieres seguir jugando usando una funcion
```
ThrowDialog()
```