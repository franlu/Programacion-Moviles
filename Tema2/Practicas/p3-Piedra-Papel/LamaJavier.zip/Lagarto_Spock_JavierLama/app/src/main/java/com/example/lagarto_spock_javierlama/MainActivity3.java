package com.example.lagarto_spock_javierlama;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {
    TextView txtDecision;
    Button btnVolver;
    AlertDialog.Builder dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        txtDecision = findViewById(R.id.txtDecision);

        Bundle bundle = getIntent().getExtras();
        String variableImportada=bundle.getString("decision");
        txtDecision.setText(variableImportada);

        btnVolver = findViewById(R.id.btnVolver);

        btnVolver.setOnClickListener((v) -> {
            dialog = new AlertDialog.Builder(MainActivity3.this);
            dialog.setTitle("¿De verdad?");
            dialog.setMessage("¿Seguro seguro?");

            dialog.setPositiveButton("CONTINUAR", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo, int id) {
                    dialogo.cancel();
                    Intent intent = new Intent (v.getContext(), MainActivity2.class);
                    startActivityForResult(intent, 0);
                }
            });
            dialog.setNegativeButton("SALIR DE APP", new DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialogo, int id) {
                    finish();
                }
            });
            dialog.show();
        });

    }
}