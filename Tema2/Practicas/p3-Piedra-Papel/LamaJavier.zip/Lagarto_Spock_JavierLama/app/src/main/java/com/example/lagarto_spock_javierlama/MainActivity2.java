package com.example.lagarto_spock_javierlama;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import java.util.Random;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener{
    ImageButton imgBtnPiedra, imgBtnPapel, imgBtnTijeras, imgBtnLagarto, imgBtnSpock;
    AlertDialog.Builder dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        imgBtnLagarto = findViewById(R.id.imgBtnLagarto);
        imgBtnPapel = findViewById(R.id.imgBtnPapel);
        imgBtnSpock = findViewById(R.id.imgBtnSpock);
        imgBtnTijeras = findViewById(R.id.imgBtnTijeras);
        imgBtnPiedra = findViewById(R.id.imgBtnPiedra);

        imgBtnPiedra.setOnClickListener(this);
        imgBtnSpock.setOnClickListener(this);
        imgBtnPapel.setOnClickListener(this);
        imgBtnTijeras.setOnClickListener(this);
        imgBtnLagarto.setOnClickListener(this);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu1, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
                dialog = new AlertDialog.Builder(MainActivity2.this);
                dialog.setTitle("Reglas:");
                dialog.setMessage("Consulte internet :)");

                dialog.setPositiveButton("Buscador", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo, int id) {
                        dialogo.cancel();
                        String url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ&ab_channel=RickAstley";
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(url));
                        startActivity(i);
                    }
                });
                dialog.setNegativeButton("SALIR DE LA APP", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialogo, int id) {
                        finish();
                    }
                });
                dialog.show();
                break;
        }
        return false;
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.imgBtnPiedra:
                if(elegirGanador(0)){
                    Intent intent = new Intent (view.getContext(), MainActivity3.class);
                    intent.putExtra("decision", "Ganado!!");
                    startActivityForResult(intent, 0);
                    finish();
                }else{
                    Intent intent = new Intent (view.getContext(), MainActivity3.class);
                    intent.putExtra("decision", "Perdido!!");
                    startActivityForResult(intent, 0);
                    finish();
                }
            break;
            case R.id.imgBtnPapel:
                if(elegirGanador(1)){
                    Intent intent = new Intent (view.getContext(), MainActivity3.class);
                    intent.putExtra("decision", "Ganado!!");
                    startActivityForResult(intent, 0);
                    finish();
                }else{
                    Intent intent = new Intent (view.getContext(), MainActivity3.class);
                    intent.putExtra("decision", "Perdido!!");
                    startActivityForResult(intent, 0);
                    finish();
                }
            break;
            case R.id.imgBtnTijeras:
                if(elegirGanador(2)){
                    Intent intent = new Intent (view.getContext(), MainActivity3.class);
                    intent.putExtra("decision", "Ganado!!");
                    startActivityForResult(intent, 0);
                    finish();
                }else{
                    Intent intent = new Intent (view.getContext(), MainActivity3.class);
                    intent.putExtra("decision", "Perdido!!");
                    startActivityForResult(intent, 0);
                    finish();
                }
            break;
            case R.id.imgBtnLagarto:
                if(elegirGanador(3)){
                    Intent intent = new Intent (view.getContext(), MainActivity3.class);
                    intent.putExtra("decision", "Ganado!!");
                    startActivityForResult(intent, 0);
                    finish();
                }else{
                    Intent intent = new Intent (view.getContext(), MainActivity3.class);
                    intent.putExtra("decision", "Perdido!!");
                    startActivityForResult(intent, 0);
                    finish();
                }
                break;
            case R.id.imgBtnSpock:
                if(elegirGanador(4)){
                    Intent intent = new Intent (view.getContext(), MainActivity3.class);
                    intent.putExtra("decision", "Ganado!!");
                    startActivityForResult(intent, 0);
                    finish();
                }else{
                    Intent intent = new Intent (view.getContext(), MainActivity3.class);
                    intent.putExtra("decision", "Perdido!!");
                    startActivityForResult(intent, 0);
                    finish();
                }
                break;
        }
    }

    public static boolean elegirGanador(int boton){
        String tipos[] = {"piedra", "papel", "tijera", "lagarto", "spock"};
        Random ran = new Random();
        int elecMaquina = ran.nextInt(5);

        if((boton == 0 && (elecMaquina == 2 || elecMaquina == 3 )) || (boton == 1 && (elecMaquina == 0 || elecMaquina == 4 ))
                || (boton == 2 && (elecMaquina == 1 || elecMaquina == 3 )) || (boton == 3 && (elecMaquina == 1 || elecMaquina == 4 ))
                || (boton == 4 && (elecMaquina == 2 || elecMaquina == 0 ))){
            return true;
        }else{
            return false;
        }

    }
}