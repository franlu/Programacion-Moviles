# Juego_Lagarto_spock
---
## - Partes y uso
Este proyecto esta dividido en *3 mainActivity* cada uno con una funcionalidad diferente. Lo he decidido hacer de esta forma para poder diferenciar la presentacion, el juego y el resultado.
### MainActivity1
- Es una simple presentación del juego en el que aparece texto y un botón con el que se entrará a la ventana del juego. 

### MainActivity2
- Tiene 5 botones con la imagen de la piedra, el papel, la tijera, el lagarto y spock. El jugador pulsará uno de estos para jugar y así enviar su decisión con lo que él decide sacar. 
- El codigo internamente tiene una funcion que devuelve un booleano que sera true en el caso de que el jugador gane y false si este pierde. Dentro de la función onClick hago un switch con un caso para cada botón en el que llamara a la funcion anterior y hago un condicional en el caso de verdadero o falso y paso a la siguiente ventana para ver el resultado.
- Tiene un menú en el que aparece una ventana de ayuda, esta redirige a una web en la que se explican las reglas del juego.

### MainActivity3
- Recibe la informacion de victoria o derrota del anterior MainActivity y muestra si el jugador ha ganado o ha perdido. Debajo aparece un botón para volver a jugar y al pulsarlo sale un dialog que da como opción salir de la aplicación o volver a jugar lo que devolvería al MainActivity2.
