package com.example.martinmarin_piedrapt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageButton rockB;
    ImageButton paperB;
    ImageButton scissorsB;
    ImageButton lizardB;
    ImageButton spockB;

    boolean[][] versus = {/*Rock*/ {false, true, true, false},
                          /*Paper*/ {true, false, false, true},
                          /*Scissors*/ {false, true, true, false},
                          /*Lizard*/ {false, true, false, true},
                          /*Spock*/ {true, false, true, false} };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rockB = (ImageButton) findViewById(R.id.rockBut);
        paperB = (ImageButton) findViewById(R.id.paperBut);
        scissorsB = (ImageButton) findViewById(R.id.scissorsBut);
        lizardB = (ImageButton) findViewById(R.id.lizardBut);
        spockB = (ImageButton) findViewById(R.id.spockBut);

        rockB.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

            }
        });

        rockB.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startVersus(0);
            }
        });

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_activity, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.gameItem:

                return true;
            case R.id.statsItem:
                View v = new View();
                Intent intent = new Intent (v.getContext(), StatsActivity.class);
                return true;
            case R.id.aboutItem:

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void startVersus(int playerID){

    }
}