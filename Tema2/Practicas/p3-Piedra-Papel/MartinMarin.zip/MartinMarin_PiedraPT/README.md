# PiedraPapelTijeraAndroid
Proyecto para la creación del juego de Piedra, Papel y Tijeras en una aplicación de Android.

La idea principal es una ventana de juego que presente las tres opciones de juego al usuario, una vez este escoja se le presenta la 
elección de la máquina y el resultado, también se podria presentar una puntuación para ver cuantas veces ha ganado cada parte. Desde 
un menú desplegable, el usuario puede acceder a una ventana con estadísticas del juego y otra para ver información sobre la aplicación.
